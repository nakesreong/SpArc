---------------------------------------------------------------------------------------
--  SpArc/Presets.lua — Bilingual Localization System (EN / RU), AI Prompt Templates
--                      & 4 Active Class Rotation Profiles (Shadow Priest, Frost Mage,
--                      Assassination Rogue, Arms Warrior) with AoE & Misc Support.
--  Authors: Gemini (Tiger) & Anya (5cr3am1ng5oul)
---------------------------------------------------------------------------------------
local _G = _G
local SpArc = _G.SpArc or _G.SparkArc or {}
_G.SpArc = SpArc
_G.SparkArc = SpArc

local GetLocale = _G.GetLocale

function SpArc:GetActiveLang()
  local db = _G.SpArcDB
  local pref = db and db.visual and db.visual.lang
  if pref == "RU" or pref == "EN" then
    return pref
  end
  local loc = (GetLocale and GetLocale()) or "enUS"
  if loc == "ruRU" then
    return "RU"
  end
  return "EN"
end

function SpArc:IsRU()
  return SpArc:GetActiveLang() == "RU"
end

local STRINGS = {
  EN = {
    WINDOW_TITLE = "|cffa335eeSpArc v%s|r — Semicircle FSM Rotation & Cooldown HUD (.MD & AI)",
    WINDOW_SUBTITLE = "Authors: |cffffd100Gemini (Tiger) & Anya (5cr3am1ng5oul)|r  •  SpellID + Bartender4 Keybind Resolver",
    LANG_BTN = "Lang: EN",

    TAB_1 = "1. Presets (6)",
    TAB_2 = "2. .MD Editor & AI",
    TAB_3 = "3. Visual & HUD",
    TAB_4 = "4. Telemetry / Debug",

    NAV_1 = "Rotation Presets",
    NAV_2 = ".MD Code & AI",
    NAV_3 = "Rotation Arc",
    NAV_4 = "Saves & CDs Wings",
    NAV_5 = "Castbar & Resource",
    NAV_6 = "Combat Camera",
    NAV_7 = "Telemetry & Debug",
    NAV_8 = "Profiles",
    NAV_9 = "Macro Generator",
    NAV_10 = "Nameplates (Metro)",
    NAV_11 = "Combat Text",

    MOD_ENABLE = "Enable",
    MOD_ENABLE_SAVES = "Enable Left Saves Wing",
    MOD_ENABLE_CDS = "Enable Right CDs Wing",
    TOP_TEST_HUD = "Test HUD: %s",
    TOP_FIX_CURSOR = "Reset Cursor",

    M3_TITLE = "Rotation Arc (Semicircle / Flat Line / Bowl Queue)",
    M3_ORDER_LBL = "Order:",
    M3_ORDER_LTR = "0-1-2-3-4 (Left)",
    M3_ORDER_RTL = "4-3-2-1-0 (Mirror)",
    M3_ORDER_CENTER = "3-1-0-2-4 (Center)",
    CK_BOSS_ROT = "Enable Bursts on Boss & Rare targets (BOSS condition in .MD)",
    CK_PVP_ROT = "Enable PvP skills on Player targets (PVP condition in .MD)",
    M3_GRP_GEO = "Arc Geometry & Position (-180° Bowl Down  |  0° Flat Line  |  +180° Dome Up)",
    M3_GRP_ICONS = "Queue Icons, Border Thickness & Opacity",
    M3_GRP_FEEDBACK = "Press Animation & Feedback",
    CK_PRESS_FEEDBACK = "Animate icon press feedback (-20% -> +20% bounce) on exact spell cast",

    M4_TITLE = "Defensive Saves & Offensive Cooldowns Wings",
    M4_GRP_POS = "Wings Position & Visibility",
    M4_GRP_EMERG = "Emergency Low-HP Save Alert (Center Screen)",

    M5_TITLE = "Dual-Direction Castbar & Secondary Resource Tracker",
    M5_GRP_SIZE = "Castbar Dimensions & Offset",
    M5_GRP_CLIP = "Channeled Filler Clipping Alert",
    M5_GRP_RES = "Secondary Resource Tracker Under Castbar (Insanity / Combo Points)",
    CK_RES_ENABLE = "Show Secondary Class Resource Tracker under Castbar (Insanity, Combo Points, etc.)",
    CK_RES_ALWAYS = "Always show Resource Bar even out of combat & with no target",
    SL_RES_WIDTH = "Resource Bar Width (px)",
    SL_RES_HEIGHT = "Resource Bar Height (px)",
    SL_RES_OFFSET_X = "Resource Bar Horizontal Offset X (px)",
    SL_RES_OFFSET_Y = "Resource Bar Vertical Offset Y (px)",
    SL_RES_SCALE = "Resource Bar Scale",

    M6_TITLE = "Action Combat Camera (Mouselook)",
    M6_GRP_KEYS = "Camera & Interact Keybinds (Auto-clears if bound in WoW / Bartender4)",
    M6_HOLD_LABEL = "Unlock Cursor while held (onHold):",
    M6_TOGGLE_LABEL = "Unlock / Lock Camera permanently (onPress):",
    M6_INTERACT_LABEL = "Target by Crosshair & Interact (Target + Interact):",
    M6_BIND_WAIT = "Press key... (ESC)",
    M6_RESET_KEY = "Default",
    M6_UNBIND_KEY = "Clear",
    M6_NOT_BOUND = "Not Bound",
    M6_FIX_BTN = "Flush Hardware Cursor (/sparc fixcursor)",
    M6_GRP_CROSS = "Center Reticle / Crosshair (Live Preview while open)",
    SL_CAM_CROSS_Y = "Crosshair Vertical Height Y (px)",
    SL_CAM_CROSS_SCALE = "Crosshair Scale",
    M6_GRP_CLICK = "Mouselook Click-Casting (Bartender4 / ActionBars)",
    CK_CAM_CLICKCAST = "Bind LMB/RMB (+Shift/Ctrl/Alt) to Action Slots 1..8 while camera is locked",
    CK_AUTO_UNSHIFT = "Unshift forms out of combat on Interact (E) / Hold Cursor (G) on the ground (safe while flying)",

    M7_TITLE = "Live SpellBook & Rotation Telemetry",

    M8_TITLE = "Character Profiles (ElvUI-Style HUD, Camera, Keybinds & DoT Aura Rules)",
    M8_GRP_CUR = "Current Character, Active Profile & New Profile Creation",
    M8_CUR_SUMMARY = "Character: |cffffd100%s|r   •   Active Profile: |cff00ff96%s|r   •   DoT Aura Rules: |cff00ccff%d|r\nProfile Keys:  onHold = |cffffd100[%s]|r   |   onPress = |cffffd100[%s]|r   |   Interact = |cffffd100[%s]|r",
    M8_RESET_BTN = "Reset Current Profile",
    M8_CHAR_PROF_BTN = "Character Profile",
    M8_DEF_PROF_BTN = "'Default' Profile",
    M8_NEW_LABEL = "New Profile:",
    M8_NEW_BTN = "+ Create Profile",
    M8_GRP_LIST = "Existing Profiles (Switch Active, Copy From, or Delete)",
    M8_DETAILS_HEADER = "Selected Profile: |cffffd100%s|r\n\n"
      .. "• Hold Cursor (onHold): |cff00ccff%s|r\n"
      .. "• Toggle Camera (onPress): |cff00ccff%s|r\n"
      .. "• Interact Key: |cff00ccff%s|r\n"
      .. "• Crosshair Y / Scale: |cff00ff00%d px / %.2f|r\n"
      .. "• Arc Radius / Spread: |cff00ff00%d px / %d°|r\n"
      .. "• Tracked Nameplate DoT Rules: |cffa335ee%d rules|r\n\n"
      .. "|cffaaaaaaEach profile is 100%% isolated (HUD, Camera, Keybinds, and Nameplate DoT Aura Rules), just like ElvUI.|r",
    CK_M8_COPY_AURAS = "Also copy Nameplate DoT Aura Rules from selected profile",
    M8_ACTIVATE_BTN = "Switch to Selected Profile",
    M8_COPY_BTN = "Copy From Selected -> Current Profile",
    M8_DELETE_BTN = "Delete Selected Profile",
    MSG_PROF_SWITCHED = "|cffa335eeSpArc:|r Switched active profile to |cff00ff96%s|r.",
    MSG_PROF_CREATED = "|cffa335eeSpArc:|r Created and activated new profile |cff00ff96%s|r.",
    MSG_PROF_COPIED = "|cffa335eeSpArc:|r Copied settings from |cffffd100%s|r into |cff00ff96%s|r.",
    MSG_PROF_RESET = "|cffa335eeSpArc:|r Profile |cff00ff96%s|r reset to defaults.",
    MSG_PROF_DELETED = "|cffa335eeSpArc:|r Deleted profile |cffff6060%s|r.",
    MSG_BIND_CONFLICT_CLEARED = "|cffa335eeSpArc:|r Key |cffffd100[%s]|r is bound to '|cff00ccff%s|r' in game/addon — SpArc bind automatically cleared.",
    MSG_INTERACT_AUTO_ADAPTED = "|cffa335eeSpArc:|r Key |cffffd100[%s]|r is used by '|cff00ccff%s|r' — Interact key in SpArc automatically set to |cff00ff96[%s]|r.",

    M9_TITLE = "SpellBook Wrapper Macro Generator (Class & Spec)",
    M9_GRP_INFO = "Naming Scheme & Macro Slot Capacity",
    M9_SUMMARY_TEXT = "Class (%s): |cffffd100%s|r   •   Spec (%s): |cff00ff96%s|r\nCharacter Macros: |cff00ff96%d / %d|r   •   General (Account) Macros (Overflow): |cff00ccff%d / %d|r",
    M9_GRP_TPL = "Macro Template (use 'spell' or '%s' for Spell Name) & SpellBook Filters",
    M9_TPL_DEFAULT_BTN = "Default [@target]",
    M9_TPL_MO_BTN = "[@mouseover] + Target",
    CK_M9_SKIP_EXISTING = "Skip spells that already exist in macros",
    CK_M9_INC_CLASS = "Include General Class Spells (w1, p1, r1, d1...)",
    CK_M9_INC_SPEC = "Include Active Spec Spells (sp1, ar1, fd1, aw1...)",
    M9_GRP_PREVIEW = "SpellBook Scan Preview & Generation Log",
    M9_PREVIEW_BTN = "Rescan SpellBook Preview",
    M9_GENERATE_BTN = "Generate Wrapper Macros Now",
    M9_OPEN_MACROS_BTN = "Open /m Window",
    M9_PREVIEW_HEADER = "|cffffd100SpellBook Scan:|r Found |cffffffff%d|r active spells  ->  Will create: |cff00ff96%d Character|r + |cff00ccff%d General|r  |  Skipped: |cffaaaaaa%d|r",
    M9_OVERFLOW_WARN = "Warning: %d spell(s) will not fit (both Character and General macro tabs are full).",
    M9_ALREADY_HAS = "already in",
    M9_SLOTS_FULL = "Character & General macro slots are full!",
    M9_ERR_COMBAT = "Cannot create macros while in combat! Leave combat and try again.",
    MSG_M9_DONE = "|cffa335eeSpArc Macro Generator:|r Created |cff00ff96%d Character|r and |cff00ccff%d General|r macros (Skipped existing: |cffaaaaaa%d|r).",

    M10_TITLE = "Metro Tile Nameplates, Castbar & Dynamic Aura Colors",
    CK_NP_CLASS_ICON = "Hostile Player Class Square (Left)",
    CK_NP_FRIENDLY = "Friendly Players (Class Color)",
    M10_GRP_GEO = "Metro Tile Geometry & Live Preview",
    SL_NP_WIDTH = "Health Tile Width (px)",
    SL_NP_HEIGHT = "Health Tile Height (px)",
    SL_NP_CAST_H = "Castbar Height (px)",
    SL_NP_FONT = "Name Font Size (pt)",
    M10_PREV_BASE = "Preview: Base Hostile (Red)",
    M10_PREV_RULE = "Preview Rule #%d (%s)",
    M10_CYCLE_PREV_BTN = "Cycle Preview Color",
    M10_GRP_AURAS = "Dynamic Aura / DoT Color Rules (Auto-synced from .MD Pseudocode)",
    CK_NP_AUTO_MD = "Pull tracked DoTs automatically from active .MD rotation preset",
    M10_AURA_HINT = "DoT IDs are pulled automatically from your active .MD preset (or add custom Wowhead IDs; comma = AND combo, e.g. |cffffd100164812, 164815|r).",
    M10_ADD_RULE_BTN = "+ Add Aura Rule",
    M10_RESET_RULES_BTN = "Sync from .MD",
    M10_AND_JOIN = "AND",
    M10_INVALID_IDS = "Enter valid Aura ID(s)",
    MSG_M10_ENTER_ID = "|cffa335eeSpArc Nameplates:|r Please enter at least one numeric Aura/Spell ID (e.g. 164812).",
    NP_CONFLICT_TITLE = "|cffa335eeSpArc|r — Nameplate Addon Conflict",
    NP_CONFLICT_BODY = "SpArc Metro Nameplates are incompatible with |cffffd100%s|r.\n\nWhich nameplates would you like to use?",
    NP_CONFLICT_USE_SPARC = "Use SpArc (Metro)",
    NP_CONFLICT_USE_THEIRS = "Keep %s",
    MSG_NP_CHOICE_SPARC = "|cffa335eeSpArc Nameplates:|r Enabled SpArc Metro Nameplates (disabled %s).",
    MSG_NP_CHOICE_THEIRS = "|cffa335eeSpArc Nameplates:|r Kept %s nameplates (SpArc Metro Nameplates turned off).",

    M11_TITLE = "MSBT Movable Scroll Zones, Tactile Haptic Numbers & Distance Fade",
    M11_UNLOCK_ZONES_ON = "Lock MSBT Zones (Done Dragging)",
    M11_UNLOCK_ZONES_OFF = "Move MSBT Zones (Drag with Mouse)",
    M11_TEST_STREAM_BTN = "Test Number Fountain",
    M11_GRP_CENTER = "1. MSBT Movable Scroll Zones (Incoming & Outgoing) & Center HUD Protection",
    CK_CT_INCOMING_ZONE = "Enable MSBT INCOMING Zone (Heals / Shields / Damage Taken)",
    CK_CT_OUTGOING_ZONE = "Enable MSBT OUTGOING Zone (Target Hits & Crits)",
    CK_CT_HIDE_PLAYER = "Hide default Blizzard center column over character & suppress center spam ('Entering Combat', WindTools Shield)",
    CK_CT_SUPPRESS_ALERTS = "Suppress center-screen spam banners ('Entering/Leaving Combat', WindTools Shield/Swords, 'Target Changed', Threat)",
    M11_SCROLL_STYLE_LBL = "MSBT Curve Style:",
    M11_STYLE_ARC = "MSBT Outward Arc ( )",
    M11_STYLE_UP = "Straight Up ^",
    M11_STYLE_FOUNTAIN = "Fountain Wave ~",
    SL_CT_INC_X = "Incoming Zone X (px)",
    SL_CT_INC_Y = "Incoming Zone Y (px)",
    SL_CT_OUT_X = "Outgoing Zone X (px)",
    SL_CT_OUT_Y = "Outgoing Zone Y (px)",
    SL_CT_ARC_CURVE = "MSBT Arc Curve: ) - | - (",
    SL_CT_FONT_SIZE = "MSBT Font Size (pt)",
    M11_ZONE_INC_TITLE = "MSBT: INCOMING\n(Heals / Shields / Hits)\nDrag with Mouse",
    M11_ZONE_OUT_TITLE = "MSBT: OUTGOING\n(Target Damage & Crits)\nDrag with Mouse",
    M11_GRP_ENEMY = "2. Center Target Yellow Numbers ('Haptic'), Crit Shake & Smart AoE Filter",
    CK_CT_DIRECT_DMG = "Show yellow numbers in center",
    CK_CT_CRIT_SHAKE = "Haptic Crit Shake & Flash",
    M11_DOT_MODE_LBL = "Periodic DoT Ticks:",
    M11_DOT_AUTO = "Smart Auto-AoE (1-2: ON | 3+ pack: OFF)",
    M11_DOT_OFF = "Direct Hits Only (OFF)",
    M11_DOT_ON = "Always ON",
    CK_CT_HIDE_PET = "Hide Pet damage",
    CK_CT_HIDE_HEAL = "Hide 3D world green heals",
    CK_CT_HIDE_MISS = "Hide Dodge / Miss",
    M11_GRP_SCALE = "3. Nameplate Distance, Fade, Out-of-Combat Dimming & Stacking",
    SL_CT_WORLD_SCALE = "Center Text Size (0.65 = Compact)",
    SL_CT_OVERHEAD_ALPHA = "Center Text Brightness (0.60 = Soft)",
    SL_CT_OVERHEAD_Y = "Height Above Target Y (px)",
    SL_CT_DIR_SCALE = "3D Number Spread (0 = Tight Over Target, 2 = Wide)",
    CK_CT_SPREAD_NP = "Stacking Nameplates (ladder)",
    CK_NP_DIST_FADE = "Distance Fade (further = softer)",
    CK_NP_OOC_DIM = "Dim non-combat mobs in fight",
    SL_NP_MAX_DIST = "Nameplate Max Distance (yd)",
    SL_NP_MIN_ALPHA = "Far Nameplate Opacity",
    SL_CT_OVERLAP_V = "Vertical Stacking Step (V)",
    SL_CT_OVERLAP_H = "Horizontal Stacking Step (H)",
    M11_PRESET_HAPTIC_BTN = "'Clean Haptic' Preset",
    M11_PRESET_BLIZZ_BTN = "Restore Blizzard Defaults",
    M11_STATUS_FMT = "Active:  Center = |cff00ff96%.2f (Alpha %.0f%%, +%dpx)|r  •  DoTs = |cffffd100%s|r  •  NP = |cff00ccff%d yd (Fade %.0f%%)|r  •  Combat = |cff00ff96%d|r",
    FOOTER_CREDITS = "Special thanks for the inspiration to the creators of |cffffd100MSBT, Plater, WeakAuras, Hekili, Combat Mode & ElvUI|r —\ntheir finest ideas live on under this single high-FPS roof.",

    P1_SUMMARY = "Total Presets: |cffffd100%d|r  |  Your Class (%s): |cff00ff00%d|r  |  Active: |cffa335ee%s|r (%s)",
    FILTER_CLASS = "Filter: Only %s (%d)",
    FILTER_ALL = "Filter: All Classes (%d)",
    MODE_AUTO = "Mode: AUTO (PvE/Boss/PvP)",
    MODE_MANUAL = "Mode: Manual Preset",
    NEW_PRESET_BTN = "+ New Preset",
    DEL_PRESET_BTN = "Delete Preset",
    NEW_PRESET_TITLE = "%d. Custom %s #%d",
    MSG_PRESET_DELETED = "|cffa335eeSpArc:|r Deleted preset: |cffff6060%s|r",
    PREFIX_ACTIVE = "|cff00ff00[ACTIVE]|r ",
    PREFIX_SELECTED = "|cffffd100[>]|r ",

    DETAILS_BODY = "|cffffd100%s|r\n\n"
      .. "• Class / Mode: |cff00ccff%s (%s)|r\n"
      .. "• FSM Rotation Rules: |cff00ff00%d|r\n"
      .. "• Left Wing Saves (TRACK_SAVES): |cff00ff00%s|r\n"
      .. "• Right Wing CDs (TRACK_CDS): |cff00ff00%s|r\n"
      .. "• Nameplate DoTs (.MD): |cffa335ee%s|r\n"
      .. "• Interruptible / Protected: |cffff40a0%s|r / |cff40d0ff%s|r",
    NONE_STR = "none",

    ACTIVATE_BTN = "Set as Active Preset",
    OPEN_MD_BTN = "Edit .MD Pseudocode / AI ->",
    TEST_HUD_BTN = "Preview HUD on Screen (ON/OFF)",
    MSG_ACTIVATED = "|cffa335eeSpArc:|r Activated preset: |cffffd100%s|r",

    AI_BANNER_PREFIX = "AI Helper: ",
    AI_PROMPT_BTN = "AI Prompt (Ctrl+C)",
    AI_BACK_BTN = "<- Back to .MD Code",
    AI_STATUS_COPY = "|cff00ff00Copy this prompt (Ctrl+C), paste it into Gemini or ChatGPT with an Icy Veins / Wowhead guide, and paste the result back into the .MD editor:|r",
    EDITOR_STATUS = "Preset: |cffffd100%s|r  |  FSM Rules: |cff00ff00%d|r  |  Left Saves: |cff00ff00%d|r  |  Right CDs: |cff00ff00%d|r",
    SAVE_MD_BTN = "Save .MD to Preset",
    RESET_MD_BTN = "Reset Preset to Default",
    MSG_MD_SAVED = "|cffa335eeSpArc:|r .MD pseudocode saved and compiled for |cffffd100%s|r!",

    V_HEADER = "Configure Semicircle Rotation Arc, Side Cooldown Wings, Castbar & Minimap Button:",
    SL_ARC_RADIUS = "Arc Radius / Width (px)",
    SL_ARC_SPREAD = "Curvature (°): -180 Bowl | 0 Line | +180 Dome",
    SL_PRIMARY_SCALE = "Primary Slot #1 Scale",
    SL_QUEUE_SCALE = "Queue Slots (#2..#6) Scale",
    SL_QUEUE_LEN = "Number of Arc Icons (3..6)",
    SL_ARC_OFFSET_Y = "Arc Vertical Offset Y (px)",
    SL_PRIMARY_BORDER = "Primary Slot #1 Border Thickness (px)",
    SL_ARC_ALPHA = "Rotation Arc Opacity (%)",
    SL_CB_WIDTH = "Castbar Width (px)",
    SL_CB_OFFSET_Y = "Castbar Vertical Offset Y (px)",
    SL_EMERG_HP = "Emergency Save HP Threshold (%)",
    SL_WINGS_Y = "Side Wings Vertical Offset Y (px)",

    CK_SAVES_WING = "Show Left Defensive Saves Wing (defined by TRACK_SAVES in .MD)",
    CK_CDS_WING = "Show Right Offensive Cooldowns Wing (defined by TRACK_CDS in .MD)",
    CK_EMERG_SAVE = "Show Center Emergency Save Alert on Low HP (RETURN EMERGENCY in .MD)",
    CK_ALWAYS_CDS = "Always show enabled Side Wings even out of combat & with no target",
    CK_INTERRUPT = "Flash 'CLIP CHANNEL!' when a higher-priority spell comes ready during filler channel",
    CK_CASTBAR = "Show Dual-Direction SpArc Castbar (Left->Right cast / Right->Left channel)",
    CK_MINIMAP = "Show SpArc Minimap Button (Left-Click: Settings, Right-Click: Telemetry)",
    CK_COMBAT_CAM = "Enable SpArc Combat Camera Module (replaces CombatMode; G = hold cursor, ` = toggle)",
    CK_CAM_CROSSHAIR = "Show Combat Camera Center Crosshair when camera is locked",
    CK_TEST_MODE = "Test / Preview Mode (display full rotation arc, wings, and castbar right now)",

    TEL_HEADER = "|cffffd100Telemetry & Debugger:|r compares SpArc queue decisions against live SpellBook & Bartender4 state",
    TEL_SNAP_BTN = "Capture Snapshot Now",
    TEL_COPY_BTN = "Select All (Ctrl+C)",
    TEL_CLEAR_BTN = "Clear Log & BugSack",
    TEL_TOGGLE = "Log ON",

    HUD_SAVE_ALERT = "SAVE!",
    HUD_CLIP_BANNER = "CLIP CAST!",
    HUD_CHANNEL_BANNER = "CHANNEL...",
    HUD_RANGE_BANNER = "OUT OF RANGE!",
    HUD_CB_CLIP = "CLIP FILLER -> PRESS [%s]!",
    HUD_CB_PROTECTED = " [DO NOT CLIP]",
    HUD_TEST_CHANNEL = "Mind Flay (Filler Channel <-)",
    HUD_TEST_CAST = "Vampiric Touch (Normal Cast ->)",

    MM_TT_TITLE = "|cffa335eeSpArc v%s|r — Semicircle Rotation & Cooldown HUD",
    MM_TT_LEFT = "|cffffd100Left-Click:|r Open Presets, .MD Editor & Settings",
    MM_TT_RIGHT = "|cffffd100Right-Click:|r Open SpellBook Telemetry Debugger",
    MM_TT_SHIFT = "|cffffd100Shift + Left-Click:|r Toggle HUD Test Preview (ON/OFF)",
    MM_TT_DRAG = "|cffaaaaaaHold Left-Click: Drag button around Minimap|r",

    MSG_TEST_TOGGLE = "|cffa335eeSpArc:|r HUD Test Preview: %s",
    MSG_CAM_TOGGLE = "|cffa335eeSpArc:|r Combat Camera Module: %s",
    MSG_CURSOR_FIXED = "|cffa335eeSpArc:|r Hardware cursor & freelook centering CVars flushed.",
    MSG_ON = "|cff00ff00ON|r",
    MSG_OFF = "|cffff4040OFF|r",
  },

  RU = {
    WINDOW_TITLE = "|cffa335eeSpArc v%s|r — Визуализатор FSM-ротаций (.MD Псевдокод, ИИ & Телеметрия)",
    WINDOW_SUBTITLE = "Авторы: |cffffd100Gemini (Tiger) & Anya (5cr3am1ng5oul)|r  •  SpellID + Bartender4 Keybind Resolver",
    LANG_BTN = "Язык: RU",

    TAB_1 = "1. Пресеты (6)",
    TAB_2 = "2. Импорт .MD и ИИ",
    TAB_3 = "3. Визуал и HUD",
    TAB_4 = "4. Телеметрия / Дебаг",

    NAV_1 = "Пресеты ротаций",
    NAV_2 = "Псевдокод .MD и ИИ",
    NAV_3 = "Дуга ротации",
    NAV_4 = "Крылья Сейвов и КД",
    NAV_5 = "Кастбар и Ресурс",
    NAV_6 = "Боевая Камера",
    NAV_7 = "Телеметрия и Дебаг",
    NAV_8 = "Профили",
    NAV_9 = "Макросогенератор",
    NAV_10 = "Неймплейты (Metro)",
    NAV_11 = "Боевой Текст",

    MOD_ENABLE = "Включить",
    MOD_ENABLE_SAVES = "Включить левое крыло сейвов",
    MOD_ENABLE_CDS = "Включить правое крыло бурстов/КД",
    TOP_TEST_HUD = "Тест HUD: %s",
    TOP_FIX_CURSOR = "Сброс курсора",

    M3_TITLE = "Дуга ротации (Полукруг / Прямая линия / Чаша очереди заклинаний)",
    M3_ORDER_LBL = "Порядок:",
    M3_ORDER_LTR = "0-1-2-3-4 (Слева)",
    M3_ORDER_RTL = "4-3-2-1-0 (Зеркало)",
    M3_ORDER_CENTER = "3-1-0-2-4 (Центр)",
    CK_BOSS_ROT = "Босс / Рарник — разрешить бурсты (ветки BOSS в .MD)",
    CK_PVP_ROT = "ПвП — разрешить ПвП-контроль на игроках (ветки PVP в .MD)",
    M3_GRP_GEO = "Геометрия и изгиб дуги (-180° чаша вниз  |  0° прямая линия  |  +180° дуга вверх)",
    M3_GRP_ICONS = "Масштаб, обводка главной иконки и прозрачность",
    M3_GRP_FEEDBACK = "Отклик нажатия кнопок",
    CK_PRESS_FEEDBACK = "Имитировать нажатие иконки (-20% -> +20% размера) при прожиме спелла",

    M4_TITLE = "Боковые крылья Сейвов и Бурстов (КД)",
    M4_GRP_POS = "Положение и видимость крыльев",
    M4_GRP_EMERG = "Экстренный сейв в центре экрана (при низком ХП)",

    M5_TITLE = "Двунаправленный Кастбар и Трекер Доп. Ресурса",
    M5_GRP_SIZE = "Размеры и отступы кастбара",
    M5_GRP_CLIP = "Индикация прерывания потокового филлера",
    M5_GRP_RES = "Трекер доп. ресурса под кастбаром (Безумие / Приёмы серии)",
    CK_RES_ENABLE = "Включить трекер доп. ресурса под кастбаром (Безумие, Приёмы серии + Энергия и др.)",
    CK_RES_ALWAYS = "Всегда показывать панель ресурса (даже вне боя и без цели)",
    SL_RES_WIDTH = "Ширина панели ресурса (px)",
    SL_RES_HEIGHT = "Высота панели ресурса (px)",
    SL_RES_OFFSET_X = "Смещение ресурса по X (px)",
    SL_RES_OFFSET_Y = "Смещение ресурса по Y (px)",
    SL_RES_SCALE = "Масштаб панели ресурса",

    M6_TITLE = "Боевая Камера (Удержание камеры / Mouselook)",
    M6_GRP_KEYS = "Клавиши камеры и взаимодействия (авто-сброс при конфликте с игрой/аддонами)",
    M6_HOLD_LABEL = "Отвязать курсор при удержании (onHold):",
    M6_TOGGLE_LABEL = "Отвязать / привязать камеру насовсем (onPress):",
    M6_INTERACT_LABEL = "Таргет по прицелу и Взаимодействие (Target + Interact):",
    M6_BIND_WAIT = "Нажми клавишу... (ESC)",
    M6_RESET_KEY = "По умолч.",
    M6_UNBIND_KEY = "Снять",
    M6_NOT_BOUND = "Не назначено",
    M6_FIX_BTN = "Сбросить аппаратный курсор (/sparc fixcursor)",
    M6_GRP_CROSS = "Прицел камеры в центре экрана (показывается вживую при настройке)",
    SL_CAM_CROSS_Y = "Высота прицела по Y (px)",
    SL_CAM_CROSS_SCALE = "Масштаб прицела",
    M6_GRP_CLICK = "Боевой клик-каст мыши (Mouselook Click-Casting)",
    CK_CAM_CLICKCAST = "Перехватывать ЛКМ/ПКМ (+Shift/Ctrl/Alt) под способности 1..8 при зажатой камере",
    CK_AUTO_UNSHIFT = "Снимать облик вне боя по кнопке Взаимодействия (E) / Курсора (G) на земле (в полёте не сбрасывает)",

    M7_TITLE = "Телеметрия книги заклинаний и отладка ротации",

    M8_TITLE = "Профили (В стиле ElvUI: Изоляция HUD, Камеры, Биндов и Аур Неймплейтов)",
    M8_GRP_CUR = "Текущий профиль и создание нового профиля",
    M8_CUR_SUMMARY = "Персонаж: |cffffd100%s|r   •   Активный профиль: |cff00ff96%s|r   •   Аур DoT: |cff00ccff%d|r\nБинды профиля:  onHold = |cffffd100[%s]|r   |   onPress = |cffffd100[%s]|r   |   Interact = |cffffd100[%s]|r",
    M8_RESET_BTN = "Сбросить профиль",
    M8_CHAR_PROF_BTN = "Профиль персонажа",
    M8_DEF_PROF_BTN = "Общий (Default)",
    M8_NEW_LABEL = "Новый профиль:",
    M8_NEW_BTN = "+ Создать профиль",
    M8_GRP_LIST = "Существующие профили (Выбор активного, «Скопировать из» как в ElvUI, Удаление)",
    M8_DETAILS_HEADER = "Выбранный профиль: |cffffd100%s|r\n\n"
      .. "• Отвязать курсор (onHold): |cff00ccff%s|r\n"
      .. "• Камера вкл/выкл (onPress): |cff00ccff%s|r\n"
      .. "• Клавиша взаимодействия (Interact): |cff00ccff%s|r\n"
      .. "• Прицел (Высота Y / Масштаб): |cff00ff00%d px / %.2f|r\n"
      .. "• Дуга ротации (Радиус / Угол): |cff00ff00%d px / %d°|r\n"
      .. "• Цветовых правил аур неймплейтов (DoT): |cffa335ee%d шт.|r\n\n"
      .. "|cffaaaaaaКаждый профиль полностью изолирован (как в ElvUI): геометрия дуги, боевая камера, бинды и список отслеживаемых DoT-аур неймплейтов хранятся отдельно.|r",
    CK_M8_COPY_AURAS = "Копировать также правила аур неймплейтов (DoT) из выбранного профиля",
    M8_ACTIVATE_BTN = "Выбрать (Сделать активным)",
    M8_COPY_BTN = "Скопировать из выбранного в текущий",
    M8_DELETE_BTN = "Удалить выбранный профиль",
    MSG_PROF_SWITCHED = "|cffa335eeSpArc:|r Активный профиль переключён на |cff00ff96%s|r.",
    MSG_PROF_CREATED = "|cffa335eeSpArc:|r Создан и активирован новый профиль |cff00ff96%s|r.",
    MSG_PROF_COPIED = "|cffa335eeSpArc:|r Настройки скопированы из профиля |cffffd100%s|r в |cff00ff96%s|r.",
    MSG_PROF_RESET = "|cffa335eeSpArc:|r Профиль |cff00ff96%s|r сброшен к значениям по умолчанию.",
    MSG_PROF_DELETED = "|cffa335eeSpArc:|r Профиль |cffff6060%s|r удалён.",
    MSG_BIND_CONFLICT_CLEARED = "|cffa335eeSpArc:|r Клавиша |cffffd100[%s]|r занята действием «|cff00ccff%s|r» в игре/аддоне — бинд в SpArc автоматически снят.",
    MSG_INTERACT_AUTO_ADAPTED = "|cffa335eeSpArc:|r Клавиша |cffffd100[%s]|r занята («|cff00ccff%s|r») — клавиша Interact в SpArc автоматически переключена на |cff00ff96[%s]|r.",

    M9_TITLE = "Макросогенератор (Авто-генерация обвязок по всей книге заклинаний)",
    M9_GRP_INFO = "Схема именования и свободные слоты макросов",
    M9_SUMMARY_TEXT = "Класс (%s): |cffffd100%s|r   •   Спек (%s): |cff00ff96%s|r\nМакросы персонажа: |cff00ff96%d / %d|r   •   Общие макросы (при нехватке места): |cff00ccff%d / %d|r",
    M9_GRP_TPL = "Шаблон макроса ('spell' или '%s' = имя спелла) и фильтры спеллбука",
    M9_TPL_DEFAULT_BTN = "Шаблон [@target]",
    M9_TPL_MO_BTN = "[@mouseover] + Цель",
    CK_M9_SKIP_EXISTING = "Пропускать спеллы, для которых уже есть макрос",
    CK_M9_INC_CLASS = "Общие классовые спеллы (w1, p5, r1, d1...)",
    CK_M9_INC_SPEC = "Спеллы специализации (sp1, ar1, fd1, aw1...)",
    M9_GRP_PREVIEW = "Предпросмотр спеллбука и лог генерации макросов",
    M9_PREVIEW_BTN = "Обновить список спеллов",
    M9_GENERATE_BTN = "Сгенерировать макросы сейчас",
    M9_OPEN_MACROS_BTN = "Открыть окно /m",
    M9_PREVIEW_HEADER = "|cffffd100Сканирование спеллбука:|r Найдено |cffffffff%d|r активных спеллов  ->  Будет создано: |cff00ff96%d Персонажа|r + |cff00ccff%d Общих|r  |  Пропущено: |cffaaaaaa%d|r",
    M9_OVERFLOW_WARN = "Внимание: %d спелл(ов) не поместятся (заполнены и личные, и общие макросы).",
    M9_ALREADY_HAS = "уже есть в",
    M9_SLOTS_FULL = "Слоты макросов персонажа и общих макросов полностью заняты!",
    M9_ERR_COMBAT = "Нельзя создавать макросы в бою! Выйдите из боя и нажмите снова.",
    MSG_M9_DONE = "|cffa335eeSpArc Макросогенератор:|r Создано макросов персонажа: |cff00ff96%d|r, общих макросов: |cff00ccff%d|r (Пропущено существующих: |cffaaaaaa%d|r).",

    M10_TITLE = "Неймплейты в стиле плитки Metro, Кастбар и Цвета по Аурам (DoT)",
    CK_NP_CLASS_ICON = "Иконка класса слева у враг-игроков",
    CK_NP_FRIENDLY = "Союзные игроки (в цвет класса)",
    M10_GRP_GEO = "Размеры плитки Metro и живой предпросмотр",
    SL_NP_WIDTH = "Ширина плитки ХП (px)",
    SL_NP_HEIGHT = "Высота плитки ХП (px)",
    SL_NP_CAST_H = "Высота кастбара (px)",
    SL_NP_FONT = "Размер шрифта (pt)",
    M10_PREV_BASE = "Превью: Враг без дотов (Красный)",
    M10_PREV_RULE = "Превью правила #%d (%s)",
    M10_CYCLE_PREV_BTN = "Сменить цвет превью",
    M10_GRP_AURAS = "Цвета по аурам и дотам (Авто-подтягивание из .MD псевдокода ротации)",
    CK_NP_AUTO_MD = "Тянуть ID дотов автоматически из активного .MD пресета ротации",
    M10_AURA_HINT = "ID дотов автоматически подтягиваются из активного .MD пресета (можно менять цвета или добавлять свои ID через запятую для условия «И», напр. |cffffd100164812, 164815|r).",
    M10_ADD_RULE_BTN = "+ Добавить ауру",
    M10_RESET_RULES_BTN = "Из .MD пресета",
    M10_AND_JOIN = "И",
    M10_INVALID_IDS = "Укажи числовой ID ауры",
    MSG_M10_ENTER_ID = "|cffa335eeSpArc Неймплейты:|r Введи хотя бы один числовой ID ауры/спелла с Wowhead (например, 164812).",
    NP_CONFLICT_TITLE = "|cffa335eeSpArc|r — Конфликт неймплейтов",
    NP_CONFLICT_BODY = "Неймплейты SpArc (Metro) несовместимы с неймплейтами |cffffd100%s|r.\n\nЧто используем — меня (SpArc) или их?",
    NP_CONFLICT_USE_SPARC = "Меня — SpArc (Metro)",
    NP_CONFLICT_USE_THEIRS = "Их — %s",
    MSG_NP_CHOICE_SPARC = "|cffa335eeSpArc Неймплейты:|r Выбраны неймплейты SpArc Metro (%s отключены).",
    MSG_NP_CHOICE_THEIRS = "|cffa335eeSpArc Неймплейты:|r Оставлены неймплейты %s (неймплейты SpArc выключены).",

    M11_TITLE = "Подвижные Зоны MSBT, Тактильная «Хаптика» и Дальность Неймплейтов",
    M11_UNLOCK_ZONES_ON = "Закрепить зоны MSBT (Готово)",
    M11_UNLOCK_ZONES_OFF = "Двигать зоны MSBT (Мышкой)",
    M11_TEST_STREAM_BTN = "Тест фонтана цифр",
    M11_GRP_CENTER = "1. Подвижные Зоны MSBT (Входящий и Исходящий текст) и Защита Центра",
    CK_CT_INCOMING_ZONE = "Зона ВХОДЯЩЕГО текста (Хил / Щиты / Урон по тебе)",
    CK_CT_OUTGOING_ZONE = "Зона ИСХОДЯЩЕГО текста (Урон и криты по цели)",
    CK_CT_HIDE_PLAYER = "Убрать стандартный столб цифр по центру персонажа и баннеры («Вход в бой», щит WindTools)",
    CK_CT_SUPPRESS_ALERTS = "Отключить мусорные баннеры посреди экрана («Вход в бой», «Выход из боя», щит/мечи WindTools, «Смена цели!», Угроза)",
    M11_SCROLL_STYLE_LBL = "Траектория MSBT:",
    M11_STYLE_ARC = "Дуга MSBT в стороны ( )",
    M11_STYLE_UP = "Прямо вверх ^",
    M11_STYLE_FOUNTAIN = "Волна / Веер ~",
    SL_CT_INC_X = "Входящий X (px)",
    SL_CT_INC_Y = "Входящий Y (px)",
    SL_CT_OUT_X = "Исходящий X (px)",
    SL_CT_OUT_Y = "Исходящий Y (px)",
    SL_CT_ARC_CURVE = "Изгиб дуги: ) - | - (",
    SL_CT_FONT_SIZE = "Шрифт MSBT (pt)",
    M11_ZONE_INC_TITLE = "MSBT: ВХОДЯЩИЙ\n(Хил / Щиты / Урон)\nТяни мышкой (ЛКМ)",
    M11_ZONE_OUT_TITLE = "MSBT: ИСХОДЯЩИЙ\n(Урон и Криты по цели)\nТяни мышкой (ЛКМ)",
    M11_GRP_ENEMY = "2. Жёлтые Цифры По Центру Над Целью, Крит-Вспышка и Умный АоЕ-Фильтр",
    CK_CT_DIRECT_DMG = "Жёлтые цифры по центру",
    CK_CT_CRIT_SHAKE = "Встряска и вспышка крита",
    M11_DOT_MODE_LBL = "Тики дотов (DoT):",
    M11_DOT_AUTO = "Умное АоЕ (1-2: ВКЛ | 3+ пак: ВЫКЛ)",
    M11_DOT_OFF = "Только прямые (ВЫКЛ)",
    M11_DOT_ON = "Всегда ВКЛ",
    CK_CT_HIDE_PET = "Скрыть питомцев",
    CK_CT_HIDE_HEAL = "Скрыть 3D-хил в мире",
    CK_CT_HIDE_MISS = "Скрыть Промах/Уклон",
    M11_GRP_SCALE = "3. Дальность Неймплейтов, Фейдинг, Приглушение Не-Боевых и Лесенка",
    SL_CT_WORLD_SCALE = "Размер цифр по центру (0.65 = Мелкий)",
    SL_CT_OVERHEAD_ALPHA = "Яркость цифр по центру (0.60 = Мягко)",
    SL_CT_OVERHEAD_Y = "Высота над целью по Y (px)",
    SL_CT_DIR_SCALE = "Разлёт 3D-цифр (0 = Ровно над целью, 2 = Широкий веер)",
    CK_CT_SPREAD_NP = "Лесенка (анти-слипание)",
    CK_NP_DIST_FADE = "Фейдинг по дальности",
    CK_NP_OOC_DIM = "Приглушать не-боевых в бою",
    SL_NP_MAX_DIST = "Дальность неймплейтов (м)",
    SL_NP_MIN_ALPHA = "Прозрачность вдалеке",
    SL_CT_OVERLAP_V = "Шаг лесенки по вертикали (V)",
    SL_CT_OVERLAP_H = "Шаг лесенки по горизонтали (H)",
    M11_PRESET_HAPTIC_BTN = "Пресет «Чистая Хаптика»",
    M11_PRESET_BLIZZ_BTN = "Стандарт Blizzard",
    M11_STATUS_FMT = "Статус:  Центр = |cff00ff96%.2f (Яркость %.0f%%, +%dpx)|r  •  Доты = |cffffd100%s|r  •  Дальность NP = |cff00ccff%d м (Фейд %.0f%%)|r  •  В бою = |cff00ff96%d|r",
    FOOTER_CREDITS = "Отдельное спасибо за вдохновение авторам легендарных аддонов: |cffffd100MSBT, Plater, WeakAuras, Hekili, Combat Mode и ElvUI|r —\nмы собрали ваши лучшие идеи под одной крышей с любовью к чистым фреймам и высокому FPS.",

    P1_SUMMARY = "Всего пресетов: |cffffd100%d|r  |  Для вашего класса (%s): |cff00ff00%d|r  |  Активный: |cffa335ee%s|r (%s)",
    FILTER_CLASS = "Фильтр: Только %s (%d)",
    FILTER_ALL = "Фильтр: Все классы (%d)",
    MODE_AUTO = "Режим: AUTO (ПвЕ/Босс/ПвП)",
    MODE_MANUAL = "Режим: Ручной пресет",
    NEW_PRESET_BTN = "+ Новый пресет",
    DEL_PRESET_BTN = "Удалить пресет",
    NEW_PRESET_TITLE = "%d. Кастомный %s #%d",
    MSG_PRESET_DELETED = "|cffa335eeSpArc:|r Пресет удалён: |cffff6060%s|r",
    PREFIX_ACTIVE = "|cff00ff00[АКТИВЕН]|r ",
    PREFIX_SELECTED = "|cffffd100[>]|r ",

    DETAILS_BODY = "|cffffd100%s|r\n\n"
      .. "• Класс / Режим: |cff00ccff%s (%s)|r\n"
      .. "• Правил ротации в автомате: |cff00ff00%d|r\n"
      .. "• Крыло сейвов слева (TRACK_SAVES): |cff00ff00%s|r\n"
      .. "• Крыло бурстов справа (TRACK_CDS): |cff00ff00%s|r\n"
      .. "• Доты неймплейтов (из .MD): |cffa335ee%s|r\n"
      .. "• Филлер / Защита канала: |cffff40a0%s|r / |cff40d0ff%s|r",
    NONE_STR = "нет",

    ACTIVATE_BTN = "Сделать активным пресетом",
    OPEN_MD_BTN = "Открыть псевдокод .MD / ИИ ->",
    TEST_HUD_BTN = "Тест HUD на экране (ВКЛ/ВЫКЛ)",
    MSG_ACTIVATED = "|cffa335eeSpArc:|r Активирован пресет: |cffffd100%s|r",

    AI_BANNER_PREFIX = "ИИ-Подсказка: ",
    AI_PROMPT_BTN = "Промпт для ИИ (Ctrl+C)",
    AI_BACK_BTN = "<- Вернуться к .MD коду",
    AI_STATUS_COPY = "|cff00ff00Скопируйте этот промпт (Ctrl+C), отправьте своему Gemini или ChatGPT вместе с гайдом с Icy Veins / Wowhead и вставьте ответ обратно в редактор .MD:|r",
    EDITOR_STATUS = "Пресет: |cffffd100%s|r  |  Правил FSM: |cff00ff00%d|r  |  Сейвов слева: |cff00ff00%d|r  |  КД справа: |cff00ff00%d|r",
    SAVE_MD_BTN = "Сохранить .MD в пресет",
    RESET_MD_BTN = "Сброс пресета по умолч.",
    MSG_MD_SAVED = "|cffa335eeSpArc:|r Псевдокод .MD сохранён и скомпилирован для |cffffd100%s|r!",

    V_HEADER = "Настройки полукруга ротации, боковых крыльев сейвов/КД, кастбара и миникарты:",
    SL_ARC_RADIUS = "Радиус / ширина дуги ротации (px)",
    SL_ARC_SPREAD = "Изгиб дуги (°): -180 вниз | 0 линия | +180 вверх",
    SL_PRIMARY_SCALE = "Масштаб главной иконки #1",
    SL_QUEUE_SCALE = "Масштаб очереди (#2..#6)",
    SL_QUEUE_LEN = "Кол-во иконок в дуге (3..6)",
    SL_ARC_OFFSET_Y = "Смещение дуги по Y (px)",
    SL_PRIMARY_BORDER = "Толщина обводки главной иконки #1 (px)",
    SL_ARC_ALPHA = "Прозрачность дуги ротации (%)",
    SL_CB_WIDTH = "Ширина кастбара (px)",
    SL_CB_OFFSET_Y = "Смещение кастбара по Y (px)",
    SL_EMERG_HP = "Порог ХП экстренного сейва (%)",
    SL_WINGS_Y = "Высота крыльев сейвов/КД по Y (px)",

    CK_SAVES_WING = "Показывать левое крыло сейвов (строка TRACK_SAVES в .MD псевдокоде)",
    CK_CDS_WING = "Показывать правое крыло бурстов и КД (строка TRACK_CDS в .MD псевдокоде)",
    CK_EMERG_SAVE = "Показывать экстренный сейв в центре при низком ХП (RETURN EMERGENCY в .MD)",
    CK_ALWAYS_CDS = "Всегда показывать включенные крылья сейвов/КД (даже вне боя и без цели)",
    CK_INTERRUPT = "Подсвечивать 'ПРЕРВИ КАСТ!', когда во время филлера (Пытка разума) откатился спелл",
    CK_CASTBAR = "Показывать двойной кастбар SpArc (слева->направо каст / справа->налево потоковый)",
    CK_MINIMAP = "Показывать иконку-кнопку SpArc у миникарты (ЛКМ — настройки, ПКМ — телеметрия)",
    CK_COMBAT_CAM = "Включить модуль Combat Camera в SpArc (замена CombatMode; G = курсор при зажатии, ` = вкл/выкл)",
    CK_CAM_CROSSHAIR = "Показывать прицел Combat Camera в центре экрана при зажатой камере",
    CK_TEST_MODE = "Тестовый режим (показать превью всей дуги, кастбара и крыльев прямо сейчас)",

    TEL_HEADER = "|cffffd100Телеметрия и Дебаг:|r сравнивает выбор SpArc с реальным ответом книги заклинаний и панелей Bartender4",
    TEL_SNAP_BTN = "Снять слепок сейчас",
    TEL_COPY_BTN = "Выделить всё (Ctrl+C)",
    TEL_CLEAR_BTN = "Очистить лог и BugSack",
    TEL_TOGGLE = "Сбор ВКЛ",

    HUD_SAVE_ALERT = "СЕЙВ!",
    HUD_CLIP_BANNER = "ПРЕРВИ КАСТ!",
    HUD_CHANNEL_BANNER = "КАНАЛ...",
    HUD_RANGE_BANNER = "ДАЛЕКО!",
    HUD_CB_CLIP = "ПРЕРВИ ФИЛЛЕР -> ЖМИ [%s]!",
    HUD_CB_PROTECTED = " [НЕ ПРЕРЫВАЙ]",
    HUD_TEST_CHANNEL = "Пытка разума (Филлер <-)",
    HUD_TEST_CAST = "Прикосновение вампира (Каст ->)",

    MM_TT_TITLE = "|cffa335eeSpArc v%s|r — Rotation & Cooldown HUD",
    MM_TT_LEFT = "|cffffd100ЛКМ:|r Открыть окно настроек, .MD псевдокода и пресетов",
    MM_TT_RIGHT = "|cffffd100ПКМ:|r Открыть Телеметрию / Дебаг книги заклинаний",
    MM_TT_SHIFT = "|cffffd100Shift + ЛКМ:|r Тестовый режим HUD (ВКЛ/ВЫКЛ)",
    MM_TT_DRAG = "|cffaaaaaaЗажать ЛКМ: Перетащить кнопку вокруг миникарты|r",

    MSG_TEST_TOGGLE = "|cffa335eeSpArc:|r Тестовый режим: %s",
    MSG_CAM_TOGGLE = "|cffa335eeSpArc:|r Модуль Combat Camera: %s",
    MSG_CURSOR_FIXED = "|cffa335eeSpArc:|r Аппаратный курсор и CVar центрирования камеры сброшены.",
    MSG_ON = "|cff00ff00ВКЛ|r",
    MSG_OFF = "|cffff4040ВЫКЛ|r",
  },
}

function SpArc:L(key)
  local lang = SpArc:GetActiveLang()
  local tbl = STRINGS[lang] or STRINGS.EN
  return tbl[key] or STRINGS.EN[key] or key
end

SpArc.AIPromptHeader_EN =
  "Ask Gemini or ChatGPT to convert any Icy Veins / Wowhead rotation guide "
  .. "into SpArc .MD pseudocode and paste it straight into this editor!"

SpArc.AIPromptHeader_RU =
  "Попросите своего Gemini или ChatGPT написать вам ротацию с Icy Veins / Wowhead "
  .. "на псевдокоде в формате SpArc .MD и засуньте её сюды!"

SpArc.AIPromptTemplate_EN = [[Hello Gemini / ChatGPT / Claude!
Please look up the latest rotation guide on Icy Veins or Wowhead for World of Warcraft: Midnight (12.x) and compile a ready-to-import rotation profile for the SpArc addon strictly in the SpArc .MD pseudocode format described below.

====================================================================
1. TARGET CHARACTER & CONTENT
====================================================================
• Class & Spec: [INSERT CLASS & SPEC, e.g., Frost Mage / Spellslinger]
• Hero Talents / Build: [OPTIONAL, e.g., Spellslinger / Frostfire / Default Icy Veins]
• Content Mode: [PvE Universal ST + AoE / Raid Boss / PvP Arena]

====================================================================
2. HOW THE SPARC .MD COMPILER WORKS (STRICT SYNTAX RULES)
====================================================================
SpArc compiles a Markdown (.MD) document into a 5-step lookahead Finite State Machine (FSM).
Output ONLY a single raw code block following these exact 6 sections:

SECTION A — HEADER METADATA:
# PROFILE: <Preset Title>
# CLASS: <WARRIOR | PALADIN | HUNTER | ROGUE | PRIEST | DEATHKNIGHT | SHAMAN | MAGE | WARLOCK | MONK | DRUID | DEMONHUNTER | EVOKER>
# SPEC: <Spec Name>
# MODE: <PVE | BOSS | PVP>
# TARGET_DEBUFF: ID:<id1,id2> | NAME:"Russian Name","English Name"

SECTION B — ## SPELL_BOOK:
Every spell used anywhere in the profile (rotation, saves, cooldowns, emergency, misc/buffs) MUST be declared here, one per line:
SPELL <KEY> = ID:<id1,id2> | NAME:"Russian Name","English Name" | CD:<sec> | ICON:<FileDataID> [| optional flags]
• Supported optional flags (separated by ` | `):
  - `CD:<seconds>` : Base cooldown in seconds (`0` if none).
  - `CHARGES:<N>` : Max charges for multi-charge abilities (e.g., `CHARGES:2`).
  - `GAIN:<N>` : Primary resource generated on cast (0..100 scale; for Combo Point classes 1 CP = 20).
  - `COST:<N> | SPENDER:true` : Primary resource cost (for 4+ CP spenders use `COST:80 | SPENDER:true`).
  - `BURST:<sec>` : Marks ability as a burst window cooldown lasting `<sec>` seconds (enables `player.in_burst`).
  - `AURA_ID:<id1,id2> | AURA_DUR:<sec> | AURA_UNIT:<target|player>` : WeakAuras-style aura metadata! Any DoT, debuff, stackable aura, or player buff is queried uniformly via `target.aura(KEY).rem`, `target.aura(KEY).stacks`, `player.aura(KEY).rem`, `player.aura(KEY).stacks` (or standalone `AURA <KEY> = ID:<id1,id2> | AURA_UNIT:target | NAME:"..."`).
  - `STACKS:+N` / `STACKS:-N | CONSUMES_STACKS:true` : Generates or consumes target aura stacks in lookahead simulation.
  - `PROC_ONLY:true` : Only castable when glowing (`IsSpellOverlayed`) or active as a temporary spell override.
  - `OVERRIDE_OF:<BASE_KEY>` : For combo/transformation spells that replace another spell.
  - `GRANTS:<PROC_KEY>` : Casting this spell guarantees a proc of `<PROC_KEY>`.
  - `EXECUTE:true` : Execute ability (usable below 20% target HP or on proc).
  - `LOCK_CHANNEL:true` / `FILLER_INTERRUPTIBLE:true` : Channel protection or interrupt policy.
  - `ICON:<FileDataID>` : Numeric WoW icon texture ID.

SECTION C — ## CHANNEL_POLICY:
INTERRUPT_CHANNEL_ON_HIGHER_PRIORITY: <KEY1, KEY2 or NONE>
PROTECT_CHANNEL: <KEY1, KEY2 or NONE>

SECTION D — ## TRACKERS:
TRACK_SAVES: <DEFENSIVE_1>, <DEFENSIVE_2>, <DEFENSIVE_3>, <DEFENSIVE_4>
TRACK_CDS: <OFFENSIVE_CD_1>, <OFFENSIVE_CD_2>, <OFFENSIVE_CD_3>, <OFFENSIVE_CD_4>
TRACK_DOTS: <TARGET_DOT_1>, <TARGET_DOT_2> (Note: Nameplates also auto-detect any `target.aura(KEY)` in ROTATION_QUEUE!)

SECTION E — ## EMERGENCY_SAVE:
IF player.hp_percent <= 25 AND READY(<DEFENSIVE_KEY>) THEN
    RETURN EMERGENCY(<DEFENSIVE_KEY>)
END IF

SECTION F — ## ROTATION_QUEUE (Top-to-Bottom Priority FSM):
Use `IF <condition> THEN` / `ELSE IF <condition> THEN` / `ELSE` / `END IF` with `RETURN CAST(<KEY>)` inside each branch.
• Allowed condition primitives (combinable with `AND` / `OR`):
  - `READY(KEY)` / `NOT READY(KEY)` — spell is off cooldown (or has >= 1 charge).
  - `USABLE(KEY)` — spell is off cooldown AND player has enough resource/mana/target state.
  - `PROC(KEY)` / `NOT PROC(KEY)` — spell has an active proc overlay or active `OVERRIDE_OF` transformation.
  - `target.aura(KEY_OR_ID).rem <= 1` / `target.aura(KEY_OR_ID).rem > 0` — WeakAuras-style remaining duration (in seconds) of aura `KEY` or numeric Wowhead SpellID on `target` (`0` if absent).
  - `target.aura(KEY_OR_ID).stacks >= N` — current stack count of aura `KEY` or numeric SpellID on `target`.
  - `player.aura(KEY_OR_ID).rem > 0` / `player.aura(KEY_OR_ID).stacks >= N` — remaining duration or stack count of buff/debuff on `player`.
  - `player.in_burst` / `NOT player.in_burst` — any `BURST:<sec>` cooldown is currently active.
  - `player.energy <= N` / `player.combo_points <= N` / `player.insanity >= N` — current player resource check.
  - `enemies >= N` (or `AOE`, `CLEAVE`, `SINGLE_TARGET`) — number of nearby enemies in combat range.
  - `player.stealthed` / `NOT player.stealthed` — player is currently in Stealth.
  - `player.in_combat` / `NOT player.in_combat` — player is currently in combat.
  - `target.can_pick_pocket` — stealthed, humanoid/undead/demon NPC target in 10yd range not yet pick-pocketed.
  - `CHARGES(KEY) >= N` — current charge count.
• Always end with an unconditional `ELSE` -> `RETURN CAST(<FILLER_KEY>)` and `END IF`.]]

SpArc.AIPromptTemplate = [[Привет, Gemini / ChatGPT / Claude!
Сходи, пожалуйста, на Icy Veins или Wowhead, изучи актуальный гайд по ротации для World of Warcraft: Midnight (12.x) и напиши мне готовый профиль ротации для аддона SpArc строго на языке псевдокода SpArc .MD по правилам ниже.

====================================================================
1. ПАРАМЕТРЫ ПЕРСОНАЖА И КОНТЕНТА
====================================================================
• Класс и спек: [УКАЖИ КЛАСС И СПЕК, например: Друид Сила зверя / Разбойник Ликвидация / Воин Оружие / Маг Льда / Жрец Тьмы]
• Героические таланты / билд: [ПО ЖЕЛАНИЮ]
• Тип контента: [Универсальный СТ + АоЕ (с авто-определением числа врагов рядом и подхватом бурста)]

====================================================================
2. ПРАВИЛА КОМПИЛЯТОРА SPARC .MD (СТРОГАЯ СПЕЦИФИКАЦИЯ)
====================================================================
Аддон SpArc напрямую компилирует текстовый .MD-профиль в конечный автомат (FSM) и просчитывает очередь ротации на 5 шагов вперёд.
Выведи В ОТВЕТЕ ТОЛЬКО ОДИН кодовый блок без лишнего текста, строго соблюдая структуру из 6 секций:

СЕКЦИЯ А — МЕТАДАННЫЕ ПРОФИЛЯ (ШАПКА):
# PROFILE: <Название пресета>
# CLASS: <WARRIOR | PALADIN | HUNTER | ROGUE | PRIEST | DEATHKNIGHT | SHAMAN | MAGE | WARLOCK | MONK | DRUID | DEMONHUNTER | EVOKER>
# SPEC: <Английское название спека, например: Feral, Frost, Shadow, Assassination, Arms>
# MODE: <PVE | BOSS | PVP>

СЕКЦИЯ Б — ## SPELL_BOOK (КНИГА ЗАКЛИНАНИЙ И АУР):
Каждое заклинание и аура (включая урон, доты, стаки, сейвы, КД, баффы и инвиз/misc), которые используются в профиле, ОБЯЗАТЕЛЬНО объявляются отдельной строкой:
SPELL <КЛЮЧ_КАПСОМ> = ID:<id1,id2> | NAME:"Русское имя","English Name" | CD:<сек> | ICON:<FileDataID> [| доп. флаги]
AURA <КЛЮЧ_КАПСОМ> = ID:<id1,id2> | AURA_UNIT:<target|player> | AURA_DUR:<сек> | NAME:"Русское имя","English Name"
• Доступные флаги поведения (разделяются через ` | `):
  - `CD:<секунды>` — базовое время восстановления (`0`, если без КД).
  - `CHARGES:<N>` — максимум зарядов, если у спелла 2+ заряда.
  - `GAIN:<N>` — сколько ресурса генерирует каст (0..100; для комбо-поинтов 1 КП = 20).
  - `COST:<N> | SPENDER:true` — сколько ресурса тратит спелл (для финишеров от 4+ КП ставь `COST:80 | SPENDER:true`).
  - `BURST:<секунды>` — помечает способность как бурст-окно длительностью `<секунды>` (включает `player.in_burst`).
  - `AURA_ID:<id1,id2> | AURA_DUR:<секунды> | AURA_UNIT:<target|player>` — единая система аур (как в WeakAuras)! В игре доты, дебаффы со стаками и баффы — это всё ауры с ID с Wowhead, временем (`rem`) и стаками (`stacks`). Если ID ауры совпадает с ID спелла, достаточно `AURA_DUR:<сек>`.
  - `STACKS:+N` / `STACKS:-N | CONSUMES_STACKS:true` — генерация и трата стаков ауры на цели в симуляции очереди.
  - `PROC_ONLY:true` — спелл доступен ТОЛЬКО при свечении прока (`IsSpellOverlayed`) или активной подмене `OVERRIDE_OF`.
  - `OVERRIDE_OF:<БАЗОВЫЙ_КЛЮЧ>` — для комбо-заклинаний, заменяющих базовую кнопку.
  - `GRANTS:<КЛЮЧ_ПРОКА>` — каст гарантированно даёт прок `<КЛЮЧ_ПРОКА>`.
  - `EXECUTE:true` — экзекут-способность (активна при ХП цели < 20% или по проку).
  - `LOCK_CHANNEL:true` / `FILLER_INTERRUPTIBLE:true` — защита канала или разрешение прерывать потоковый филлер.
  - `ICON:<FileDataID>` — числовой ID текстуры иконки WoW.

СЕКЦИЯ В — ## CHANNEL_POLICY:
INTERRUPT_CHANNEL_ON_HIGHER_PRIORITY: <КЛЮЧ1, КЛЮЧ2 или NONE>
PROTECT_CHANNEL: <КЛЮЧ1, КЛЮЧ2 или NONE>

СЕКЦИЯ Г — ## TRACKERS (БОКОВЫЕ КРЫЛЬЯ ХУДА И ДОТЫ НЕЙМПЛЕЙТОВ):
TRACK_SAVES: <СЕЙВ_1>, <СЕЙВ_2>, <СЕЙВ_3>, <СЕЙВ_4>
TRACK_CDS: <БУРСТ_1>, <БУРСТ_2>, <БУРСТ_3>, <БУРСТ_4>
TRACK_DOTS: <ДОТ_1>, <ДОТ_2> (Неймплейты также автоматически подтягивают все `target.aura(KEY)` из ROTATION_QUEUE!)

СЕКЦИЯ Д — ## EMERGENCY_SAVE (ЭКСТРЕННЫЙ СЕЙВ В ЦЕНТРЕ ЭКРАНА):
IF player.hp_percent <= 25 AND READY(<КЛЮЧ_СЕЙВА>) THEN
    RETURN EMERGENCY(<КЛЮЧ_СЕЙВА>)
END IF

СЕКЦИЯ Е — ## ROTATION_QUEUE (ПРИОРИТЕТЫ РОТАЦИИ СВЕРХУ ВНИЗ):
Строится строго конструкцией `IF <условие> THEN` / `ELSE IF <условие> THEN` / `ELSE` / `END IF`, внутри каждой ветки пишется `RETURN CAST(<КЛЮЧ>)`.
• Разрешённые условия (можно комбинировать через `AND` и `OR`):
  - `READY(KEY)` / `NOT READY(KEY)` — спелл откатился (или имеет >= 1 заряда).
  - `USABLE(KEY)` — спелл откатился И хватает ресурса/маны/условий.
  - `PROC(KEY)` / `NOT PROC(KEY)` — активен прок (свечение кнопки) или подмена `OVERRIDE_OF`.
  - `target.aura(KEY_OR_ID).rem <= 1` / `target.aura(KEY_OR_ID).rem > 0` — единая проверка времени ауры (доты, дебаффа или баффа на цели) по ключу или прямо по числовому ID с Wowhead (если ауры нет — `rem` равен `0`, поэтому `rem <= 1` покрывает и первое наложение, и обновление на последней секунде!).
  - `target.aura(KEY_OR_ID).stacks >= N` — проверка числа стаков ауры на цели.
  - `player.aura(KEY_OR_ID).rem > 0` / `player.aura(KEY_OR_ID).stacks >= N` — проверка времени или стаков ауры (баффа/бурста/дебаффа) на самом игроке.
  - `player.in_burst` / `NOT player.in_burst` — активно ли любое бурст-окно (`BURST:<сек>`).
  - `player.energy <= N` / `player.combo_points <= N` / `player.insanity >= N` — проверка ресурсов игрока.
  - `enemies >= N` (или `AOE`, `CLEAVE`, `SINGLE_TARGET`) — количество врагов рядом в радиусе боя (как в WeakAuras по неймплейтам и дистанции).
  - `player.stealthed` / `NOT player.stealthed` — находится ли персонаж в Незаметности (Stealth).
  - `player.in_combat` / `NOT player.in_combat` — находится ли персонаж в бою.
  - `target.can_pick_pocket` — игрок в инвизе, цель — гуманоид/нежить/демон в радиусе 10м с ещё не обчищенными карманами.
  - `CHARGES(KEY) >= N` — проверка числа зарядов.
• В самом конце ОБЯЗАТЕЛЬНО должна быть ветка `ELSE` -> `RETURN CAST(<КЛЮЧ_ФИЛЛЕРА>)` и закрывающий `END IF`.]]

function SpArc:GetAIPromptHeader()
  if SpArc:IsRU() then
    return SpArc.AIPromptHeader_RU
  end
  return SpArc.AIPromptHeader_EN
end

function SpArc:GetAIPromptTemplate()
  if SpArc:IsRU() then
    return SpArc.AIPromptTemplate or SpArc.AIPromptTemplate_EN
  end
  return SpArc.AIPromptTemplate_EN
end

local EN_PRESET_TITLES = {
  PRIEST_01_SHADOW_PVE = "1. Priest: Shadow (ST / AoE)",
  MAGE_04_FROST_PVE    = "2. Mage: Frost (ST / AoE)",
  ROGUE_01_ASSA_PVE    = "3. Rogue: Assassination (ST / AoE)",
  WARRIOR_02_ARGS_BOSS = "4. Warrior: Arms (ST / AoE)",
  DRUID_01_FERAL_PVE   = "5. Druid: Feral (ST / AoE)",
  DRUID_02_BALANCE_PVE = "6. Druid: Balance (Moonkin — ST / AoE)",
}

function SpArc:GetPresetDisplayTitle(pr)
  if not pr then return "" end
  if SpArc:IsRU() then
    return pr.title or pr.id or ""
  end
  if pr.id and EN_PRESET_TITLES[pr.id] then
    return EN_PRESET_TITLES[pr.id]
  end
  return pr.title or pr.id or ""
end

SpArc.PROFILE_SCHEMA_VERSION = 36

---------------------------------------------------------------------------------------
--         6 ACTIVE BUILT-IN PRESETS (PRIEST, MAGE, ROGUE, WARRIOR, DRUID)           --
---------------------------------------------------------------------------------------
SpArc.BuiltInPresetOrder = {}
SpArc.BuiltInPresets = {}

local function RegisterPreset(id, classTag, title, mode, mdBody)
  SpArc.BuiltInPresetOrder[#SpArc.BuiltInPresetOrder + 1] = id
  SpArc.BuiltInPresets[id] = {
    id = id,
    class = classTag,
    title = title,
    mode = mode,
    md = mdBody,
  }
end

-- ====================================================================================
-- #1: PRIEST — Shadow (Ньарлатхотеп: Leveling / ST / AoE)
-- ====================================================================================
RegisterPreset("PRIEST_01_SHADOW_PVE", "PRIEST", "1. Жрец: Тьма (ШП — Левелинг / СТ / АоЕ)", "PVE", [[
# PROFILE: 1. Жрец: Тьма (ШП — Левелинг / СТ / АоЕ)
# CLASS: PRIEST
# SPEC: Shadow
# MODE: PVE

## SPELL_BOOK
SPELL SHADOWFORM = ID:232698 | AURA_ID:232698 | AURA_UNIT:player | AURA_DUR:3600 | NAME:"Облик Тьмы","Shadowform" | CD:0 | ICON:136200
SPELL SILENCE = ID:15487 | NAME:"Безмолвие","Silence" | CD:45 | INTERRUPT:true | ICON:458230
SPELL PSYCHIC_HORROR = ID:64044,8122 | NAME:"Глубинный ужас","Ментальный крик","Psychic Horror","Psychic Scream" | CD:45 | PVP:true | ICON:237568
SPELL TENTACLE_SLAM = ID:1227280,205385,457042,1234796 | AURA_ID:34914 | AURA_DUR:21 | NAME:"Мощный удар щупальцем","Темное сокрушение","Shadow Crash","Tentacle Slam" | CD:15 | CHARGES:2 | HASTED_CD:true | ONCE_PER_QUEUE:true | GAIN:15 | ICON:136201
SPELL VAMPIRIC_TOUCH = ID:34914 | AURA_ID:34914 | AURA_DUR:21 | NAME:"Прикосновение вампира","Vampiric Touch" | CD:0 | CHARGES:1 | GAIN:6 | ICON:135978
AURA SHADOW_WORD_PAIN = ID:589 | AURA_UNIT:target | AURA_DUR:16 | NAME:"Слово Тьмы: Боль","Shadow Word: Pain" | ICON:136207
SPELL VOID_ERUPTION = ID:228260,391109,194249 | AURA_ID:194249,391109 | AURA_UNIT:player | AURA_DUR:20 | BURST:20 | BOSS:true | NAME:"Облик Бездны","Извержение Бездны","Темное вознесение","Voidform","Void Eruption","Dark Ascension" | CD:120 | ICON:537079
SPELL POWER_INFUSION = ID:10060 | AURA_ID:10060 | AURA_UNIT:player | AURA_DUR:15 | BURST:15 | BOSS:true | NAME:"Придание сил","Power Infusion" | CD:120 | ICON:135939
SPELL VOID_BOLT = ID:1242173,205448 | NAME:"Залп Бездны","Стрела Бездны","Void Volley","Void Bolt" | CD:6 | GAIN:10 | OVERRIDE_OF:VOID_ERUPTION | PROC_ONLY:true | ICON:1386548
SPELL DEVOURING_PLAGUE = ID:335467 | AURA_ID:335467 | AURA_DUR:6 | NAME:"Слово Тьмы: Безумие","Всепожирающая чума","Shadow Word: Madness","Devouring Plague" | CD:0 | COST:50 | SPENDER:true | ICON:252997
SPELL SHADOW_WORD_DEATH = ID:32379 | NAME:"Слово Тьмы: Смерть","Shadow Word: Death" | CD:10 | GAIN:10 | EXECUTE:true | ICON:136149
SPELL MIND_BLAST = ID:450983,8092 | NAME:"Выброс Бездны","Взрыв разума","Void Blast","Mind Blast" | CD:7.5 | CHARGES:1 | HASTED_CD:true | GAIN:15 | ICON:136224
SPELL VOID_TORRENT = ID:263165 | NAME:"Поток бездны","Поток Бездны","Void Torrent" | CD:45 | CHARGES:1 | GAIN:35 | LOCK_CHANNEL:true | ICON:1386551
SPELL MIND_FLAY_INSANITY = ID:391403 | NAME:"Пытка разума: безумие","Mind Flay: Insanity" | CD:0 | GAIN:16 | OVERRIDE_OF:MIND_FLAY | PROC_ONLY:true | ICON:136208
SPELL MIND_FLAY = ID:15407 | NAME:"Пытка разума","Mind Flay" | CD:0 | GAIN:12 | FILLER_INTERRUPTIBLE:true | ICON:136208
SPELL PSYFIEND = ID:34433,211522,375901,451235,200174 | BOSS:true | NAME:"Исчадие Тьмы","Ментальный демон","Игры разума","Призрак Бездны","Shadowfiend","Psyfiend" | CD:60 | ICON:136199
SPELL DISPERSION = ID:47585 | NAME:"Слияние с тьмой","Слияние с Тьмой","Dispersion" | CD:90 | ICON:237563
SPELL DESPERATE_PRAYER = ID:19236 | NAME:"Молитва отчаяния","Desperate Prayer" | CD:90 | ICON:237550
SPELL VAMPIRIC_EMBRACE = ID:15286 | NAME:"Объятия вампира","Vampiric Embrace" | CD:120 | ICON:136230
SPELL FADE = ID:586,8122 | NAME:"Уход в тень","Ментальный крик","Fade","Psychic Scream" | CD:30 | ICON:135994
SPELL POWER_WORD_SHIELD = ID:17 | NAME:"Слово силы: Щит","Power Word: Shield" | CD:7.5 | ICON:135940

## CHANNEL_POLICY
INTERRUPT_CHANNEL_ON_HIGHER_PRIORITY: MIND_FLAY
PROTECT_CHANNEL: VOID_TORRENT

## TRACKERS
TRACK_SAVES: DISPERSION, DESPERATE_PRAYER, VAMPIRIC_EMBRACE, FADE
TRACK_CDS: POWER_INFUSION, VOID_ERUPTION, VOID_TORRENT, PSYFIEND, SILENCE
TRACK_DOTS: VAMPIRIC_TOUCH, SHADOW_WORD_PAIN, DEVOURING_PLAGUE

## EMERGENCY_SAVE
IF player.hp_percent <= 20 AND READY(DISPERSION) THEN
    RETURN EMERGENCY(DISPERSION)
ELSE IF player.hp_percent <= 25 AND READY(DESPERATE_PRAYER) THEN
    RETURN EMERGENCY(DESPERATE_PRAYER)
ELSE IF player.hp_percent <= 25 AND READY(VAMPIRIC_EMBRACE) THEN
    RETURN EMERGENCY(VAMPIRIC_EMBRACE)
END IF

## ROTATION_QUEUE
IF target.casting_interruptible AND READY(SILENCE) THEN
    RETURN CAST(SILENCE)
ELSE IF PVP AND target.casting_interruptible AND READY(PSYCHIC_HORROR) THEN
    RETURN CAST(PSYCHIC_HORROR)
ELSE IF NOT player.aura(SHADOWFORM) AND NOT player.aura(VOID_ERUPTION) AND READY(SHADOWFORM) THEN
    RETURN CAST(SHADOWFORM)
ELSE IF target.aura(VAMPIRIC_TOUCH).rem <= 1 AND READY(TENTACLE_SLAM) THEN
    RETURN CAST(TENTACLE_SLAM)
ELSE IF target.aura(VAMPIRIC_TOUCH).rem <= 1 AND NOT READY(TENTACLE_SLAM) THEN
    RETURN CAST(VAMPIRIC_TOUCH)
ELSE IF BOSS AND READY(VOID_ERUPTION) THEN
    RETURN CAST(VOID_ERUPTION)
ELSE IF BOSS AND READY(POWER_INFUSION) THEN
    RETURN CAST(POWER_INFUSION)
ELSE IF BOSS AND READY(PSYFIEND) THEN
    RETURN CAST(PSYFIEND)
ELSE IF PROC(VOID_BOLT) AND READY(VOID_BOLT) THEN
    RETURN CAST(VOID_BOLT)
ELSE IF PROC(DEVOURING_PLAGUE) AND USABLE(DEVOURING_PLAGUE) THEN
    RETURN CAST(DEVOURING_PLAGUE)
ELSE IF PROC(SHADOW_WORD_DEATH) AND READY(SHADOW_WORD_DEATH) THEN
    RETURN CAST(SHADOW_WORD_DEATH)
ELSE IF USABLE(SHADOW_WORD_DEATH) AND READY(SHADOW_WORD_DEATH) THEN
    RETURN CAST(SHADOW_WORD_DEATH)
ELSE IF PROC(MIND_BLAST) AND READY(MIND_BLAST) THEN
    RETURN CAST(MIND_BLAST)
ELSE IF USABLE(DEVOURING_PLAGUE) THEN
    RETURN CAST(DEVOURING_PLAGUE)
ELSE IF READY(VOID_TORRENT) THEN
    RETURN CAST(VOID_TORRENT)
ELSE IF READY(MIND_BLAST) THEN
    RETURN CAST(MIND_BLAST)
ELSE IF READY(TENTACLE_SLAM) THEN
    RETURN CAST(TENTACLE_SLAM)
ELSE IF PROC(MIND_FLAY_INSANITY) THEN
    RETURN CAST(MIND_FLAY_INSANITY)
ELSE
    RETURN CAST(MIND_FLAY)
END IF
]])

-- ====================================================================================
-- #2: MAGE — Frost (Калиратри / Морвара: ST + AoE)
-- ====================================================================================
RegisterPreset("MAGE_04_FROST_PVE", "MAGE", "2. Маг: Лёд (Фрост — СТ / АоЕ)", "PVE", [[
# PROFILE: 2. Маг: Лёд (Фрост — СТ / АоЕ)
# CLASS: MAGE
# SPEC: Frost
# MODE: PVE

## SPELL_BOOK
AURA FREEZING = ID:1221389,228358,205708 | AURA_UNIT:target | AURA_DUR:15 | NAME:"Обледенение","Замерзание","Freezing","Зимняя стужа","Winter's Chill"
SPELL COUNTERSPELL = ID:2139 | NAME:"Антимагия","Counterspell" | CD:24 | INTERRUPT:true | ICON:135856
SPELL FROST_NOVA = ID:122,113724 | NAME:"Кольцо льда","Кольцо мороза","Frost Nova","Ring of Frost" | CD:30 | PVP:true | ICON:135848
SPELL ICY_VEINS = ID:12472 | AURA_ID:12472 | AURA_UNIT:player | AURA_DUR:20 | BURST:20 | BOSS:true | NAME:"Стылая кровь","Icy Veins" | CD:120 | ICON:135838
SPELL RAY_OF_FROST = ID:205021 | BOSS:true | NAME:"Морозный луч","Луч холода","Ray of Frost" | CD:60 | CHARGES:1 | STACKS:+3 | LOCK_CHANNEL:true | ICON:1698700
SPELL COMET_STORM = ID:153595,455396 | NAME:"Кометная буря","Comet Storm" | CD:30 | STACKS:+2 | PROC_ONLY:true | OVERRIDE_OF:RAY_OF_FROST | ICON:1033912
SPELL GLACIAL_SPIKE = ID:199786,257537 | NAME:"Ледниковый шип","Черная стрела","Glacial Spike","Ebonbolt" | CD:0 | STACKS:+2 | PROC_ONLY:true | OVERRIDE_OF:FROSTBOLT | ICON:1394891
SPELL FLURRY = ID:44614 | NAME:"Шквал","Flurry" | CD:30 | CHARGES:2 | HASTED_CD:true | STACKS:+2 | ICON:135859
SPELL FROZEN_ORB = ID:84714 | NAME:"Ледяной шар","Мерзлая сфера","Frozen Orb" | CD:60 | STACKS:+2 | ICON:629077
SPELL ICE_LANCE = ID:30455 | NAME:"Ледяное копье","Ice Lance" | CD:0 | CONSUMES_STACKS:true | STACKS:-4 | ICON:135844
SPELL BLIZZARD = ID:190356,1248829 | NAME:"Снежная буря","Blizzard" | CD:12 | ICON:135858
SPELL FROSTBOLT = ID:431044,116 | NAME:"Ледяная стрела","Стрела ледяного огня","Frostbolt","Frostfire Bolt" | CD:0 | STACKS:+1 | ICON:135846
SPELL ICE_BLOCK = ID:45438,414658 | NAME:"Ледяная глыба","Холодная хватка","Ice Block","Ice Cold" | CD:240 | CHARGES:2 | ICON:135841
SPELL ICE_BARRIER = ID:11426,235313,431038 | NAME:"Ледяная преграда","Пылающая преграда","Пылающий барьер","Ice Barrier","Blazing Barrier" | CD:25 | CHARGES:1 | ICON:135988
SPELL ALTER_TIME = ID:342245,108978 | NAME:"Манипуляции со временем","Путешествие во времени","Alter Time" | CD:60 | ICON:609811
SPELL COLD_SNAP = ID:235219,55342 | NAME:"Холодная хватка","Зеркальное изображение","Cold Snap","Mirror Image" | CD:120 | ICON:135865

## CHANNEL_POLICY
PROTECT_CHANNEL: RAY_OF_FROST

## TRACKERS
TRACK_SAVES: ICE_BLOCK, ICE_BARRIER, ALTER_TIME, COLD_SNAP
TRACK_CDS: ICY_VEINS, RAY_OF_FROST, FROZEN_ORB, FLURRY, COMET_STORM, COUNTERSPELL
TRACK_DOTS: FREEZING

## EMERGENCY_SAVE
IF player.hp_percent <= 25 AND READY(ICE_BLOCK) THEN
    RETURN EMERGENCY(ICE_BLOCK)
ELSE IF player.hp_percent <= 25 AND READY(ICE_BARRIER) THEN
    RETURN EMERGENCY(ICE_BARRIER)
END IF

## ROTATION_QUEUE
IF target.casting_interruptible AND READY(COUNTERSPELL) THEN
    RETURN CAST(COUNTERSPELL)
ELSE IF BOSS AND READY(ICY_VEINS) THEN
    RETURN CAST(ICY_VEINS)
ELSE IF PVP AND READY(FROST_NOVA) THEN
    RETURN CAST(FROST_NOVA)
ELSE IF PROC(COMET_STORM) AND READY(COMET_STORM) THEN
    RETURN CAST(COMET_STORM)
ELSE IF PROC(GLACIAL_SPIKE) AND READY(GLACIAL_SPIKE) THEN
    RETURN CAST(GLACIAL_SPIKE)
ELSE IF PROC(FLURRY) AND READY(FLURRY) THEN
    RETURN CAST(FLURRY)
ELSE IF enemies >= 3 AND READY(FROZEN_ORB) THEN
    RETURN CAST(FROZEN_ORB)
ELSE IF (enemies >= 3 OR PROC(BLIZZARD)) AND READY(BLIZZARD) THEN
    RETURN CAST(BLIZZARD)
ELSE IF BOSS AND CHARGES(RAY_OF_FROST) >= 2 AND READY(RAY_OF_FROST) THEN
    RETURN CAST(RAY_OF_FROST)
ELSE IF READY(FROZEN_ORB) THEN
    RETURN CAST(FROZEN_ORB)
ELSE IF BOSS AND READY(RAY_OF_FROST) THEN
    RETURN CAST(RAY_OF_FROST)
ELSE IF READY(FLURRY) THEN
    RETURN CAST(FLURRY)
ELSE IF PROC(ICE_LANCE) AND READY(ICE_LANCE) THEN
    RETURN CAST(ICE_LANCE)
ELSE IF target.aura(FREEZING).stacks >= 4 AND READY(ICE_LANCE) THEN
    RETURN CAST(ICE_LANCE)
ELSE
    RETURN CAST(FROSTBOLT)
END IF
]])

-- ====================================================================================
-- #3: ROGUE — Assassination (Улак: ST + AoE + Подхват бурста)
-- ====================================================================================
RegisterPreset("ROGUE_01_ASSA_PVE", "ROGUE", "3. Разбойник: Ликвидация (Мути — СТ / АоЕ)", "PVE", [[
# PROFILE: 3. Разбойник: Ликвидация (Мути — СТ / АоЕ)
# CLASS: ROGUE
# SPEC: Assassination
# MODE: PVE

## SPELL_BOOK
SPELL KICK = ID:1766 | NAME:"Пинок","Kick" | CD:15 | INTERRUPT:true | ICON:132219
SPELL KIDNEY_SHOT = ID:408,1833 | NAME:"Удар по почкам","Подлый трюк","Kidney Shot","Cheap Shot" | CD:20 | PVP:true | ICON:132298
SPELL DEATHMARK = ID:360194 | AURA_ID:360194 | AURA_UNIT:target | AURA_DUR:16 | BURST:16 | BOSS:true | NAME:"Знак смерти","Метка смерти","Deathmark" | CD:120 | ICON:4667421
SPELL KINGSBANE = ID:385627 | AURA_ID:385627 | AURA_UNIT:target | AURA_DUR:14 | BURST:14 | BOSS:true | NAME:"Погибель королей","Kingsbane" | CD:60 | GAIN:20 | ICON:1373906
SPELL SHIV = ID:5938,319504 | BOSS:true | NAME:"Отравляющий укол","Shiv" | CD:30 | CHARGES:1 | GAIN:20 | ICON:135428
SPELL GARROTE = ID:703 | AURA_ID:703 | AURA_DUR:18 | NAME:"Гаррота","Garrote" | CD:13 | GAIN:20 | ICON:132297
SPELL RUPTURE = ID:1943 | AURA_ID:1943 | AURA_DUR:24 | NAME:"Рваная рана","Rupture" | CD:0 | COST:80 | SPENDER:true | ICON:132302
SPELL CRIMSON_TEMPEST = ID:1247227,121411 | AURA_ID:121411 | AURA_DUR:12 | NAME:"Кровавый вихрь","Crimson Tempest" | CD:14 | COST:80 | SPENDER:true | ICON:461860
SPELL ENVENOM = ID:32645,196819 | NAME:"Отравление","Потрошение","Envenom","Eviscerate" | CD:0 | COST:80 | SPENDER:true | ICON:132287
SPELL AMBUSH = ID:8676 | NAME:"Внезапный удар","Ambush" | CD:0 | GAIN:40 | PROC_ONLY:true | OVERRIDE_OF:MUTILATE | ICON:132282
SPELL MUTILATE = ID:1329,1752 | NAME:"Расправа","Коварный удар","Mutilate","Sinister Strike" | CD:0 | GAIN:40 | FILLER_INTERRUPTIBLE:true | ICON:132304
SPELL FAN_OF_KNIVES = ID:51723 | NAME:"Веер клинков","Fan of Knives" | CD:0 | GAIN:20 | ICON:236273
SPELL VANISH = ID:1856 | NAME:"Исчезновение","Vanish" | CD:120 | ICON:132331
SPELL CLOAK_OF_SHADOWS = ID:31224 | NAME:"Плащ теней","Cloak of Shadows" | CD:120 | ICON:136177
SPELL EVASION = ID:5277 | NAME:"Ускользание","Evasion" | CD:120 | ICON:136205
SPELL CRIMSON_VIAL = ID:185311 | NAME:"Алый фиал","Crimson Vial" | CD:30 | ICON:1373900
SPELL FEINT = ID:1966 | NAME:"Уловка","Feint" | CD:15 | CHARGES:2 | ICON:132294

## TRACKERS
TRACK_SAVES: CRIMSON_VIAL, EVASION, CLOAK_OF_SHADOWS, FEINT
TRACK_CDS: DEATHMARK, KINGSBANE, SHIV, VANISH, KICK
TRACK_DOTS: GARROTE, RUPTURE, CRIMSON_TEMPEST

## EMERGENCY_SAVE
IF player.hp_percent <= 35 AND READY(CRIMSON_VIAL) THEN
    RETURN EMERGENCY(CRIMSON_VIAL)
ELSE IF player.hp_percent <= 25 AND READY(EVASION) THEN
    RETURN EMERGENCY(EVASION)
ELSE IF player.hp_percent <= 20 AND READY(CLOAK_OF_SHADOWS) THEN
    RETURN EMERGENCY(CLOAK_OF_SHADOWS)
END IF

## ROTATION_QUEUE
IF target.casting_interruptible AND READY(KICK) THEN
    RETURN CAST(KICK)
ELSE IF PVP AND player.combo_points >= 4 AND READY(KIDNEY_SHOT) THEN
    RETURN CAST(KIDNEY_SHOT)
ELSE IF target.aura(GARROTE).rem <= 1 AND READY(GARROTE) THEN
    RETURN CAST(GARROTE)
ELSE IF target.aura(RUPTURE).rem <= 1 AND READY(RUPTURE) THEN
    RETURN CAST(RUPTURE)
ELSE IF BOSS AND READY(DEATHMARK) THEN
    RETURN CAST(DEATHMARK)
ELSE IF BOSS AND READY(KINGSBANE) THEN
    RETURN CAST(KINGSBANE)
ELSE IF BOSS AND player.in_burst AND READY(SHIV) THEN
    RETURN CAST(SHIV)
ELSE IF enemies >= 2 AND READY(CRIMSON_TEMPEST) THEN
    RETURN CAST(CRIMSON_TEMPEST)
ELSE IF READY(ENVENOM) THEN
    RETURN CAST(ENVENOM)
ELSE IF PROC(AMBUSH) AND READY(AMBUSH) THEN
    RETURN CAST(AMBUSH)
ELSE IF enemies >= 3 AND READY(FAN_OF_KNIVES) THEN
    RETURN CAST(FAN_OF_KNIVES)
ELSE
    RETURN CAST(MUTILATE)
END IF
]])

-- ====================================================================================
-- #4: WARRIOR — Arms (Моржовый: ST + AoE Размашистые/Рассекающий)
-- ====================================================================================
RegisterPreset("WARRIOR_02_ARGS_BOSS", "WARRIOR", "4. Воин: Оружие (Армс — СТ / АоЕ)", "PVE", [[
# PROFILE: 4. Воин: Оружие (Армс — СТ / АоЕ)
# CLASS: WARRIOR
# SPEC: Arms
# MODE: PVE

## SPELL_BOOK
SPELL PUMMEL = ID:6552 | NAME:"Зуботычина","Pummel" | CD:15 | INTERRUPT:true | ICON:132938
SPELL STORM_BOLT = ID:107570,1715 | NAME:"Удар громовержца","Подрезать сухожилия","Storm Bolt","Hamstring" | CD:30 | PVP:true | ICON:613535
SPELL COLOSSUS_SMASH = ID:167105,262161,436358 | AURA_ID:208086 | AURA_DUR:10 | BURST:10 | NAME:"Удар колосса","Миротворец","Сокрушение","Colossus Smash","Warbreaker","Demolish" | CD:45 | CHARGES:1 | ICON:132355
SPELL BLADESTORM = ID:227847,389774,228920 | BOSS:true | NAME:"Вихрь клинков","Опустошитель","Bladestorm","Ravager" | CD:90 | CHARGES:1 | ICON:236303
SPELL EXECUTE = ID:163201,5308,281000 | NAME:"Казнь","Execute" | CD:0 | CHARGES:1 | EXECUTE:true | ICON:135358
SPELL SWEEPING_STRIKES = ID:260708 | AURA_ID:260708 | AURA_UNIT:player | AURA_DUR:15 | NAME:"Размашистые удары","Sweeping Strikes" | CD:30 | CHARGES:1 | ICON:132366
SPELL REND = ID:772,384318,376079 | AURA_ID:772,388539 | AURA_DUR:15 | NAME:"Кровопускание","Громогласный рык","Копье чемпиона","Rend","Thunderous Roar","Champion's Spear" | CD:0 | CHARGES:1 | ICON:132155
SPELL AVATAR = ID:107574 | AURA_ID:107574 | AURA_UNIT:player | AURA_DUR:20 | BURST:20 | BOSS:true | NAME:"Аватара","Avatar" | CD:90 | CHARGES:1 | ICON:613534
SPELL MORTAL_STRIKE = ID:12294 | NAME:"Смертельный удар","Mortal Strike" | CD:6 | CHARGES:1 | ICON:132355
SPELL OVERPOWER = ID:7384 | NAME:"Превосходство","Overpower" | CD:12 | CHARGES:2 | ICON:132223
SPELL CLEAVE = ID:845 | NAME:"Рассекающий удар","Cleave" | CD:4.5 | CHARGES:1 | ICON:132338
SPELL SLAM = ID:1680,1464,6343 | NAME:"Вихрь","Мощный удар","Удар грома","Whirlwind","Slam","Thunder Clap" | CD:0 | CHARGES:1 | FILLER_INTERRUPTIBLE:true | ICON:132369
SPELL DIE_BY_THE_SWORD = ID:118038 | NAME:"Бой насмерть","Die by the Sword" | CD:120 | CHARGES:1 | ICON:132336
SPELL RALLYING_CRY = ID:97462,383762 | NAME:"Ободряющий клич","Горестная невосприимчивость","Rallying Cry","Bitter Immunity" | CD:180 | CHARGES:1 | ICON:132351
SPELL SPELL_REFLECTION = ID:23920 | NAME:"Отражение заклинаний","Spell Reflection" | CD:25 | CHARGES:1 | ICON:132361
SPELL IMPENDING_VICTORY = ID:202168 | NAME:"Верная победа","Impending Victory" | CD:25 | CHARGES:1 | ICON:589768

## TRACKERS
TRACK_SAVES: DIE_BY_THE_SWORD, RALLYING_CRY, SPELL_REFLECTION, IMPENDING_VICTORY
TRACK_CDS: AVATAR, COLOSSUS_SMASH, BLADESTORM, SWEEPING_STRIKES, PUMMEL
TRACK_DOTS: REND, COLOSSUS_SMASH

## EMERGENCY_SAVE
IF player.hp_percent <= 25 AND READY(DIE_BY_THE_SWORD) THEN
    RETURN EMERGENCY(DIE_BY_THE_SWORD)
ELSE IF player.hp_percent <= 35 AND READY(IMPENDING_VICTORY) THEN
    RETURN EMERGENCY(IMPENDING_VICTORY)
END IF

## ROTATION_QUEUE
IF target.casting_interruptible AND READY(PUMMEL) THEN
    RETURN CAST(PUMMEL)
ELSE IF PVP AND READY(STORM_BOLT) THEN
    RETURN CAST(STORM_BOLT)
ELSE IF enemies >= 2 AND READY(SWEEPING_STRIKES) THEN
    RETURN CAST(SWEEPING_STRIKES)
ELSE IF BOSS AND READY(AVATAR) THEN
    RETURN CAST(AVATAR)
ELSE IF PROC(EXECUTE) AND READY(EXECUTE) THEN
    RETURN CAST(EXECUTE)
ELSE IF USABLE(EXECUTE) AND READY(EXECUTE) THEN
    RETURN CAST(EXECUTE)
ELSE IF target.aura(REND).rem <= 1 AND READY(REND) THEN
    RETURN CAST(REND)
ELSE IF READY(COLOSSUS_SMASH) THEN
    RETURN CAST(COLOSSUS_SMASH)
ELSE IF enemies >= 3 AND READY(CLEAVE) THEN
    RETURN CAST(CLEAVE)
ELSE IF READY(MORTAL_STRIKE) THEN
    RETURN CAST(MORTAL_STRIKE)
ELSE IF BOSS AND READY(BLADESTORM) THEN
    RETURN CAST(BLADESTORM)
ELSE IF READY(OVERPOWER) THEN
    RETURN CAST(OVERPOWER)
ELSE IF READY(CLEAVE) THEN
    RETURN CAST(CLEAVE)
ELSE
    RETURN CAST(SLAM)
END IF
]])

-- ====================================================================================
-- #5: DRUID — Feral (Котастрофа: Midnight 12.0+ ST + AoE + Авто-подхват бурста)
-- ====================================================================================
RegisterPreset("DRUID_01_FERAL_PVE", "DRUID", "5. Друид: Сила зверя (Кот — СТ / АоЕ)", "PVE", [[
# PROFILE: 5. Друид: Сила зверя (Кот — СТ / АоЕ)
# CLASS: DRUID
# SPEC: Feral
# MODE: PVE

## SPELL_BOOK
SPELL SKULL_BASH = ID:106839 | NAME:"Лобовая атака","Skull Bash" | CD:15 | INTERRUPT:true | ICON:236946
SPELL MIGHTY_BASH = ID:5211,22570 | NAME:"Мощное оглушение","Калечение","Mighty Bash","Maim" | CD:60 | PVP:true | ICON:132114
SPELL TIGERS_FURY = ID:5217 | AURA_ID:5217 | AURA_UNIT:player | AURA_DUR:20 | BURST:20 | NAME:"Тигриное неистовство","Tiger's Fury" | CD:30 | ICON:132242
SPELL BERSERK = ID:106951,102543,343223 | AURA_ID:106951,102543 | AURA_UNIT:player | AURA_DUR:15 | BURST:15 | BOSS:true | NAME:"Берсерк","Воплощение: аватара Ашаманы","Berserk","Incarnation: Avatar of Ashamane" | CD:120 | ICON:236149
SPELL CONVOKE_THE_SPIRITS = ID:391528 | BOSS:true | NAME:"Созыв духов","Convoke the Spirits" | CD:120 | LOCK_CHANNEL:true | ICON:3636839
SPELL FERAL_FRENZY = ID:274837,1243807 | NAME:"Дикое бешенство","Безумное бешенство","Feral Frenzy","Frantic Frenzy" | CD:45 | GAIN:100 | ICON:2065580
SPELL RAKE = ID:1822 | AURA_ID:155722 | AURA_DUR:15 | NAME:"Глубокая рана","Rake" | CD:0 | GAIN:20 | ICON:132122
SPELL PRIMAL_WRATH = ID:285381 | AURA_ID:1079 | AURA_DUR:12 | NAME:"Первобытный гнев","Primal Wrath" | CD:0 | COST:80 | SPENDER:true | ICON:2065583
SPELL RIP = ID:1079 | AURA_ID:1079 | AURA_DUR:24 | NAME:"Разорвать","Rip" | CD:0 | COST:80 | SPENDER:true | ICON:132152
SPELL FEROCIOUS_BITE = ID:22568,441583,441591 | NAME:"Свирепый укус","Опустошение","Ferocious Bite","Ravage" | CD:0 | COST:80 | SPENDER:true | ICON:132127
SPELL SWIPE = ID:106785,213764 | NAME:"Размах","Swipe" | CD:0 | GAIN:20 | ICON:132141
SPELL SHRED = ID:5221 | NAME:"Полоснуть","Shred" | CD:0 | GAIN:20 | FILLER_INTERRUPTIBLE:true | ICON:136231
SPELL SURVIVAL_INSTINCTS = ID:61336 | NAME:"Инстинкты выживания","Survival Instincts" | CD:180 | CHARGES:2 | ICON:236169
SPELL BARKSKIN = ID:22812 | NAME:"Дубовая кожа","Barkskin" | CD:60 | ICON:136097
SPELL REGROWTH = ID:8936 | AURA_ID:69369 | AURA_UNIT:player | AURA_DUR:12 | NAME:"Восстановление","Regrowth","Стремительность хищника","Predatory Swiftness" | CD:0 | ICON:136085
SPELL FRENZIED_REGENERATION = ID:22842,108238 | NAME:"Неистовое восстановление","Обновление","Frenzied Regeneration","Renewal" | CD:36 | ICON:132091

## CHANNEL_POLICY
PROTECT_CHANNEL: CONVOKE_THE_SPIRITS

## TRACKERS
TRACK_SAVES: SURVIVAL_INSTINCTS, BARKSKIN, REGROWTH, FRENZIED_REGENERATION
TRACK_CDS: BERSERK, CONVOKE_THE_SPIRITS, TIGERS_FURY, FERAL_FRENZY, SKULL_BASH
TRACK_DOTS: RAKE, RIP

## EMERGENCY_SAVE
IF player.hp_percent <= 25 AND READY(SURVIVAL_INSTINCTS) THEN
    RETURN EMERGENCY(SURVIVAL_INSTINCTS)
ELSE IF player.hp_percent <= 45 AND PROC(REGROWTH) AND READY(REGROWTH) THEN
    RETURN EMERGENCY(REGROWTH)
ELSE IF player.hp_percent <= 35 AND READY(FRENZIED_REGENERATION) THEN
    RETURN EMERGENCY(FRENZIED_REGENERATION)
ELSE IF player.hp_percent <= 40 AND READY(BARKSKIN) THEN
    RETURN EMERGENCY(BARKSKIN)
END IF

## ROTATION_QUEUE
IF target.casting_interruptible AND READY(SKULL_BASH) THEN
    RETURN CAST(SKULL_BASH)
ELSE IF PVP AND READY(MIGHTY_BASH) THEN
    RETURN CAST(MIGHTY_BASH)
ELSE IF player.stealthed AND READY(RAKE) THEN
    RETURN CAST(RAKE)
ELSE IF PROC(FEROCIOUS_BITE) AND READY(FEROCIOUS_BITE) THEN
    RETURN CAST(FEROCIOUS_BITE)
ELSE IF player.energy <= 40 AND READY(TIGERS_FURY) THEN
    RETURN CAST(TIGERS_FURY)
ELSE IF BOSS AND READY(BERSERK) THEN
    RETURN CAST(BERSERK)
ELSE IF enemies >= 2 AND target.aura(RIP).rem <= 1 AND USABLE(PRIMAL_WRATH) THEN
    RETURN CAST(PRIMAL_WRATH)
ELSE IF target.aura(RIP).rem <= 1 AND USABLE(RIP) THEN
    RETURN CAST(RIP)
ELSE IF USABLE(FEROCIOUS_BITE) THEN
    RETURN CAST(FEROCIOUS_BITE)
ELSE IF target.aura(RAKE).rem <= 1 AND READY(RAKE) THEN
    RETURN CAST(RAKE)
ELSE IF player.combo_points <= 2 AND READY(FERAL_FRENZY) THEN
    RETURN CAST(FERAL_FRENZY)
ELSE IF BOSS AND player.combo_points <= 2 AND READY(CONVOKE_THE_SPIRITS) THEN
    RETURN CAST(CONVOKE_THE_SPIRITS)
ELSE IF enemies >= 2 AND READY(SWIPE) THEN
    RETURN CAST(SWIPE)
ELSE
    RETURN CAST(SHRED)
END IF
]])

-- ====================================================================================
-- #6: DRUID — Balance (Котастрофа: Keeper of the Grove & Elune's Chosen — Midnight 12.0+)
-- ====================================================================================
RegisterPreset("DRUID_02_BALANCE_PVE", "DRUID", "6. Друид: Баланс (Сова — СТ / АоЕ)", "PVE", [[
# PROFILE: 6. Друид: Баланс (Сова — СТ / АоЕ)
# CLASS: DRUID
# SPEC: Balance
# MODE: PVE

## SPELL_BOOK
SPELL MOONKIN_FORM = ID:24858,197625 | AURA_ID:24858,197625 | AURA_UNIT:player | AURA_DUR:3600 | NAME:"Облик лунного совуха","Moonkin Form" | CD:0 | ICON:136036
SPELL SOLAR_BEAM = ID:78675 | NAME:"Столп солнечного света","Solar Beam" | CD:60 | INTERRUPT:true | ICON:252188
SPELL MIGHTY_BASH = ID:5211,132469,33786 | NAME:"Мощное оглушение","Тайфун","Смерч","Mighty Bash","Typhoon","Cyclone" | CD:30 | PVP:true | ICON:132114
SPELL CELESTIAL_ALIGNMENT = ID:194223,102560,383410,390414,1249658 | AURA_ID:194223,102560,383410,390414,1249658 | AURA_UNIT:player | AURA_DUR:15 | BURST:15 | BOSS:true | NAME:"Парад планет","Воплощение: избранный Элуны","Перевоплощение: избранный Элуны","Celestial Alignment","Incarnation: Chosen of Elune" | CD:120 | CHARGES:2 | ICON:136060
SPELL SOLAR_ECLIPSE = ID:1233346,1233272,48517,48518 | AURA_ID:48517,48518,1233346,1233272 | AURA_UNIT:player | AURA_DUR:15 | NAME:"Солнечное затмение","Лунное затмение","Затмение","Solar Eclipse","Lunar Eclipse","Eclipse" | CD:32 | CHARGES:2 | ICON:236216
SPELL FORCE_OF_NATURE = ID:205636 | AURA_ID:428735,205636 | AURA_UNIT:player | AURA_DUR:10 | BURST:10 | BOSS:true | NAME:"Сила природы","Force of Nature" | CD:60 | GAIN:20 | ICON:132129
SPELL FURY_OF_ELUNE = ID:202770 | AURA_ID:202770 | AURA_UNIT:player | AURA_DUR:8 | BURST:8 | BOSS:true | NAME:"Ярость Элуны","Fury of Elune" | CD:60 | GAIN:40 | ICON:132123
SPELL NEW_MOON = ID:274281,274282,274283 | NAME:"Новолуние","Полумесяц","Полнолуние","New Moon","Half Moon","Full Moon" | CD:20 | CHARGES:3 | GAIN:10 | ICON:1392545
SPELL CONVOKE_THE_SPIRITS = ID:391528 | BOSS:true | NAME:"Созыв духов","Convoke the Spirits" | CD:120 | LOCK_CHANNEL:true | ICON:3636839
SPELL MOONFIRE = ID:8921 | AURA_ID:164812,8921 | AURA_DUR:22 | NAME:"Лунный огонь","Moonfire" | CD:0 | GAIN:6 | ICON:136096
SPELL SUNFIRE = ID:93402 | AURA_ID:164815,93402 | AURA_DUR:18 | NAME:"Солнечный огонь","Sunfire" | CD:0 | GAIN:6 | ICON:236216
SPELL STARFALL = ID:191034 | AURA_ID:191034 | AURA_UNIT:player | AURA_DUR:8 | NAME:"Звездопад","Starfall" | CD:0 | COST:50 | SPENDER:true | ICON:236168
SPELL STARSURGE = ID:78674 | NAME:"Звездный поток","Starsurge" | CD:0 | COST:40 | SPENDER:true | ICON:135730
SPELL STARFIRE = ID:194153 | NAME:"Звездный огонь","Starfire" | CD:0 | GAIN:10 | ICON:135753
SPELL WRATH = ID:190984,5176 | NAME:"Гнев","Wrath" | CD:0 | GAIN:8 | FILLER_INTERRUPTIBLE:true | ICON:136006
SPELL BARKSKIN = ID:22812 | NAME:"Дубовая кожа","Barkskin" | CD:60 | ICON:136097
SPELL REGROWTH = ID:8936 | NAME:"Восстановление","Regrowth" | CD:0 | ICON:136085
SPELL BEAR_FORM = ID:5487 | AURA_ID:5487 | AURA_UNIT:player | AURA_DUR:3600 | NAME:"Облик медведя","Bear Form" | CD:0 | ICON:132276

## CHANNEL_POLICY
PROTECT_CHANNEL: CONVOKE_THE_SPIRITS

## TRACKERS
TRACK_SAVES: BARKSKIN, REGROWTH, BEAR_FORM, SOLAR_BEAM
TRACK_CDS: CELESTIAL_ALIGNMENT, FORCE_OF_NATURE, FURY_OF_ELUNE, CONVOKE_THE_SPIRITS, SOLAR_ECLIPSE, NEW_MOON
TRACK_DOTS: MOONFIRE, SUNFIRE

## EMERGENCY_SAVE
IF player.hp_percent <= 40 AND READY(BARKSKIN) THEN
    RETURN EMERGENCY(BARKSKIN)
ELSE IF player.hp_percent <= 30 AND READY(REGROWTH) THEN
    RETURN EMERGENCY(REGROWTH)
END IF

## ROTATION_QUEUE
IF target.casting_interruptible AND READY(SOLAR_BEAM) THEN
    RETURN CAST(SOLAR_BEAM)
ELSE IF PVP AND READY(MIGHTY_BASH) THEN
    RETURN CAST(MIGHTY_BASH)
ELSE IF NOT player.aura(MOONKIN_FORM) AND READY(MOONKIN_FORM) THEN
    RETURN CAST(MOONKIN_FORM)
ELSE IF target.aura(SUNFIRE).rem <= 3 AND READY(SUNFIRE) THEN
    RETURN CAST(SUNFIRE)
ELSE IF target.aura(MOONFIRE).rem <= 3 AND READY(MOONFIRE) THEN
    RETURN CAST(MOONFIRE)
ELSE IF PROC(STARFALL) AND enemies >= 2 AND READY(STARFALL) THEN
    RETURN CAST(STARFALL)
ELSE IF PROC(STARSURGE) AND READY(STARSURGE) THEN
    RETURN CAST(STARSURGE)
ELSE IF BOSS AND NOT ACTIVE(CELESTIAL_ALIGNMENT) AND READY(CELESTIAL_ALIGNMENT) THEN
    RETURN CAST(CELESTIAL_ALIGNMENT)
ELSE IF BOSS AND READY(FORCE_OF_NATURE) THEN
    RETURN CAST(FORCE_OF_NATURE)
ELSE IF BOSS AND READY(FURY_OF_ELUNE) THEN
    RETURN CAST(FURY_OF_ELUNE)
ELSE IF NOT player.aura(SOLAR_ECLIPSE) AND NOT player.aura(CELESTIAL_ALIGNMENT) AND READY(SOLAR_ECLIPSE) THEN
    RETURN CAST(SOLAR_ECLIPSE)
ELSE IF BOSS AND player.astral_power <= 50 AND READY(CONVOKE_THE_SPIRITS) THEN
    RETURN CAST(CONVOKE_THE_SPIRITS)
ELSE IF enemies >= 2 AND USABLE(STARFALL) THEN
    RETURN CAST(STARFALL)
ELSE IF USABLE(STARSURGE) THEN
    RETURN CAST(STARSURGE)
ELSE IF READY(NEW_MOON) THEN
    RETURN CAST(NEW_MOON)
ELSE IF PROC(STARFIRE) AND READY(STARFIRE) THEN
    RETURN CAST(STARFIRE)
ELSE IF enemies >= 2 AND READY(STARFIRE) THEN
    RETURN CAST(STARFIRE)
ELSE
    RETURN CAST(WRATH)
END IF
]])

-- Legacy compatibility map for PVE / BOSS / PVP quick mode keys
SpArc.DefaultMarkdownProfiles = {
  ["PVE"]  = SpArc.BuiltInPresets["PRIEST_01_SHADOW_PVE"].md,
  ["BOSS"] = SpArc.BuiltInPresets["PRIEST_01_SHADOW_PVE"].md,
  ["PVP"]  = SpArc.BuiltInPresets["PRIEST_01_SHADOW_PVE"].md,
}
